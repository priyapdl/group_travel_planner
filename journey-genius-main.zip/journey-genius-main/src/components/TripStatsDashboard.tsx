import { useMemo, useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { MapPin, Wallet, TrendingUp, PieChart, Calendar, CheckCircle, BarChart3, ChevronDown, Globe } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import { format, parseISO, subMonths, startOfMonth, endOfMonth, isWithinInterval } from "date-fns";
import { supabase } from "@/integrations/supabase/client";

interface Trip {
  id: string;
  name: string;
  description: string;
  start_date: string;
  end_date: string;
  status: string;
  created_at: string;
  budget: number;
}

interface TripStatsDashboardProps {
  trips: Trip[];
}

interface DestinationCount {
  name: string;
  count: number;
}

const statusColors: Record<string, string> = {
  planning: "bg-amber-500",
  confirmed: "bg-emerald-500",
  ongoing: "bg-blue-500",
  completed: "bg-slate-500",
  cancelled: "bg-red-500",
};

const statusLabels: Record<string, string> = {
  planning: "Planning",
  confirmed: "Confirmed",
  ongoing: "Ongoing",
  completed: "Completed",
  cancelled: "Cancelled",
};

const TripStatsDashboard = ({ trips }: TripStatsDashboardProps) => {
  const [isOpen, setIsOpen] = useState(true);
  const [topDestinations, setTopDestinations] = useState<DestinationCount[]>([]);
  const [loadingDestinations, setLoadingDestinations] = useState(false);

  // Fetch destination analytics
  useEffect(() => {
    const fetchDestinationAnalytics = async () => {
      if (trips.length === 0) return;
      
      setLoadingDestinations(true);
      try {
        const tripIds = trips.map(t => t.id);
        const { data, error } = await supabase
          .from("trip_destinations")
          .select("destination_id, destinations(name)")
          .in("trip_id", tripIds);

        if (error) throw error;

        // Count destination occurrences
        const destinationCounts: Record<string, number> = {};
        data?.forEach((item: any) => {
          const name = item.destinations?.name;
          if (name) {
            destinationCounts[name] = (destinationCounts[name] || 0) + 1;
          }
        });

        // Convert to sorted array
        const sorted = Object.entries(destinationCounts)
          .map(([name, count]) => ({ name, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 5);

        setTopDestinations(sorted);
      } catch (error) {
        console.error("Error fetching destination analytics:", error);
      } finally {
        setLoadingDestinations(false);
      }
    };

    fetchDestinationAnalytics();
  }, [trips]);

  const stats = useMemo(() => {
    const totalTrips = trips.length;
    const totalBudget = trips.reduce((sum, trip) => sum + (trip.budget || 0), 0);
    const completedTrips = trips.filter(t => t.status === "completed").length;
    const upcomingTrips = trips.filter(t => 
      t.status === "planning" || t.status === "confirmed"
    ).length;

    // Status breakdown
    const statusBreakdown = trips.reduce((acc, trip) => {
      acc[trip.status] = (acc[trip.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Calculate average budget
    const tripsWithBudget = trips.filter(t => t.budget && t.budget > 0);
    const avgBudget = tripsWithBudget.length > 0 
      ? tripsWithBudget.reduce((sum, t) => sum + t.budget, 0) / tripsWithBudget.length 
      : 0;

    return {
      totalTrips,
      totalBudget,
      completedTrips,
      upcomingTrips,
      statusBreakdown,
      avgBudget,
    };
  }, [trips]);

  // Monthly trip creation data for the chart
  const monthlyData = useMemo(() => {
    const today = new Date();
    const months = [];
    
    // Get last 6 months
    for (let i = 5; i >= 0; i--) {
      const monthDate = subMonths(today, i);
      const monthStart = startOfMonth(monthDate);
      const monthEnd = endOfMonth(monthDate);
      
      const tripsInMonth = trips.filter(trip => {
        if (!trip.created_at) return false;
        const createdDate = parseISO(trip.created_at);
        return isWithinInterval(createdDate, { start: monthStart, end: monthEnd });
      });

      const budgetInMonth = tripsInMonth.reduce((sum, t) => sum + (t.budget || 0), 0);

      months.push({
        month: format(monthDate, "MMM"),
        fullMonth: format(monthDate, "MMMM yyyy"),
        trips: tripsInMonth.length,
        budget: budgetInMonth,
      });
    }
    
    return months;
  }, [trips]);

  if (trips.length === 0) return null;

  const statusEntries = Object.entries(stats.statusBreakdown).sort(
    (a, b) => b[1] - a[1]
  );

  const maxDestinationCount = topDestinations.length > 0 ? topDestinations[0].count : 1;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border border-border rounded-lg p-3 shadow-lg">
          <p className="text-sm font-medium text-foreground mb-1">{payload[0]?.payload?.fullMonth}</p>
          <p className="text-sm text-primary">
            <span className="font-bold">{payload[0]?.value}</span> trips created
          </p>
        </div>
      );
    }
    return null;
  };

  const BudgetTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border border-border rounded-lg p-3 shadow-lg">
          <p className="text-sm font-medium text-foreground mb-1">{payload[0]?.payload?.fullMonth}</p>
          <p className="text-sm text-adventure">
            <span className="font-bold">₹{payload[0]?.value?.toLocaleString('en-IN')}</span> allocated
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            {payload[0]?.payload?.trips} trip{payload[0]?.payload?.trips !== 1 ? 's' : ''} this month
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen} className="mb-10">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-display font-bold text-foreground">Trip Statistics</h2>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-2">
            <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} />
            {isOpen ? "Collapse" : "Expand"}
          </Button>
        </CollapsibleTrigger>
      </div>
      
      <CollapsibleContent className="space-y-6">
        {/* Main Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Total Trips */}
          <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Total Trips</p>
                  <p className="text-4xl font-display font-bold text-foreground">{stats.totalTrips}</p>
                </div>
                <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center">
                  <MapPin className="h-7 w-7 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Total Budget */}
          <Card className="bg-gradient-to-br from-adventure/10 to-adventure/5 border-adventure/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Total Budget</p>
                  <p className="text-4xl font-display font-bold text-foreground">
                    ₹{stats.totalBudget.toLocaleString('en-IN')}
                  </p>
                </div>
                <div className="w-14 h-14 rounded-xl bg-adventure/20 flex items-center justify-center">
                  <Wallet className="h-7 w-7 text-adventure" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Completed Trips */}
          <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border-emerald-500/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Completed</p>
                  <p className="text-4xl font-display font-bold text-foreground">{stats.completedTrips}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {stats.totalTrips > 0 
                      ? `${Math.round((stats.completedTrips / stats.totalTrips) * 100)}% completion rate`
                      : "No trips yet"}
                  </p>
                </div>
                <div className="w-14 h-14 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                  <CheckCircle className="h-7 w-7 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Trips */}
          <Card className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 border-blue-500/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Upcoming</p>
                  <p className="text-4xl font-display font-bold text-foreground">{stats.upcomingTrips}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Planning & Confirmed
                  </p>
                </div>
                <div className="w-14 h-14 rounded-xl bg-blue-500/20 flex items-center justify-center">
                  <Calendar className="h-7 w-7 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Monthly Trip Creation Trends Chart */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-display flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Monthly Trip Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={monthlyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="tripGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="month" 
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                      className="text-muted-foreground"
                    />
                    <YAxis 
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                      allowDecimals={false}
                      className="text-muted-foreground"
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Area 
                      type="monotone" 
                      dataKey="trips" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={2}
                      fill="url(#tripGradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-6 mt-3 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-primary" />
                  <span className="text-muted-foreground">Trips Created</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Monthly Budget Trends Chart */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-display flex items-center gap-2">
                <Wallet className="h-5 w-5 text-adventure" />
                Monthly Budget Allocation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="budgetGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="hsl(25, 95%, 53%)" stopOpacity={1}/>
                        <stop offset="100%" stopColor="hsl(25, 95%, 53%)" stopOpacity={0.6}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="month" 
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                      className="text-muted-foreground"
                    />
                    <YAxis 
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}k`}
                      className="text-muted-foreground"
                    />
                    <Tooltip content={<BudgetTooltip />} />
                    <Bar 
                      dataKey="budget" 
                      fill="url(#budgetGradient)"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-6 mt-3 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-adventure" />
                  <span className="text-muted-foreground">Budget Allocated</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Secondary Stats Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Status Breakdown */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-display flex items-center gap-2">
                <PieChart className="h-5 w-5 text-primary" />
                Trip Status Breakdown
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {statusEntries.map(([status, count]) => (
                  <div key={status} className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${statusColors[status]}`} />
                    <span className="text-sm font-medium flex-1 capitalize">
                      {statusLabels[status] || status}
                    </span>
                    <Badge variant="secondary" className="font-mono">
                      {count}
                    </Badge>
                    <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${statusColors[status]} transition-all duration-500`}
                        style={{ width: `${(count / stats.totalTrips) * 100}%` }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground w-12 text-right">
                      {Math.round((count / stats.totalTrips) * 100)}%
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Destinations */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-display flex items-center gap-2">
                <Globe className="h-5 w-5 text-primary" />
                Top Destinations
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingDestinations ? (
                <div className="flex items-center justify-center h-32 text-muted-foreground">
                  Loading...
                </div>
              ) : topDestinations.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-32 text-muted-foreground text-sm">
                  <MapPin className="h-8 w-8 mb-2 opacity-50" />
                  No destinations added yet
                </div>
              ) : (
                <div className="space-y-3">
                  {topDestinations.map((dest, index) => (
                    <div key={dest.name} className="flex items-center gap-3">
                      <span className="text-sm font-bold text-muted-foreground w-5">{index + 1}</span>
                      <span className="text-sm font-medium flex-1 truncate">{dest.name}</span>
                      <Badge variant="secondary" className="font-mono">
                        {dest.count}
                      </Badge>
                      <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary transition-all duration-500"
                          style={{ width: `${(dest.count / maxDestinationCount) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Budget Overview */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-display flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-adventure" />
                Budget Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-sm text-muted-foreground">Total Allocated</span>
                  <span className="text-lg font-bold text-foreground">
                    ₹{stats.totalBudget.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-sm text-muted-foreground">Average per Trip</span>
                  <span className="text-lg font-bold text-foreground">
                    ₹{Math.round(stats.avgBudget).toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-sm text-muted-foreground">Trips with Budget</span>
                  <span className="text-lg font-bold text-foreground">
                    {trips.filter(t => t.budget && t.budget > 0).length} / {stats.totalTrips}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
};

export default TripStatsDashboard;
