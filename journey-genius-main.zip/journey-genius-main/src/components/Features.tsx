import { Card, CardContent } from "@/components/ui/card";
import { Brain, Route, Map, Clock, Users, Star, Wallet, Sparkles } from "lucide-react";

const features = [
  {
    icon: Brain,
    title: "AI-Powered Suggestions",
    description: "Smart recommendations for places to visit based on your preferences, time constraints, and budget",
    color: "from-primary to-primary/70",
  },
  {
    icon: Route,
    title: "Route Optimization",
    description: "Advanced algorithms to find the most efficient path for your journey, saving time and money",
    color: "from-accent to-accent/70",
  },
  {
    icon: Map,
    title: "Interactive Maps",
    description: "GPS integration with real-time navigation and location-based services across India",
    color: "from-adventure to-adventure/70",
  },
  {
    icon: Clock,
    title: "Time Management",
    description: "Calculate travel times and distances to help you make the most of your trip duration",
    color: "from-primary to-accent",
  },
  {
    icon: Users,
    title: "Group Collaboration",
    description: "Invite friends, share itineraries, and plan the perfect group adventure together seamlessly",
    color: "from-accent to-adventure",
  },
  {
    icon: Wallet,
    title: "Expense Splitting",
    description: "Automatically track and split travel costs among group members with detailed breakdowns",
    color: "from-adventure to-primary",
  },
];

const Features = () => {
  return (
    <section className="py-24 bg-background relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16 animate-fade-in">
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
            <Sparkles className="h-4 w-4" />
            Powerful Features
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6">
            Smart Features for
            <span className="bg-gradient-to-r from-primary via-accent to-adventure bg-clip-text text-transparent">
              {" "}
              Seamless Travel
            </span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Advanced technology meets intuitive design to make group travel planning effortless and enjoyable
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card
                key={index}
                className="border-2 hover:border-primary/50 transition-all duration-300 hover:shadow-xl group bg-card/50 backdrop-blur-sm"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="p-8">
                  <div className={`mb-6 inline-flex p-4 rounded-2xl bg-gradient-to-br ${feature.color} shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <h3 className="text-xl md:text-2xl font-semibold mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground text-base leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Features;
