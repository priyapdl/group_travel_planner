import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Clock, Star, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import hassanImg from "@/assets/destination-hassan.jpg";
import beachImg from "@/assets/destination-beach.jpg";
import mountainImg from "@/assets/destination-mountains.jpg";

const destinations = [
  {
    id: 1,
    name: "Hassan, Karnataka",
    image: hassanImg,
    places: 8,
    duration: "2-3 days",
    description: "Ancient temples and heritage architecture including UNESCO World Heritage sites",
    rating: 4.8,
    category: "Historical",
  },
  {
    id: 2,
    name: "Coastal Paradise",
    image: beachImg,
    places: 12,
    duration: "3-4 days",
    description: "Pristine beaches, water sports, and stunning sunsets along the coastline",
    rating: 4.7,
    category: "Beach",
  },
  {
    id: 3,
    name: "Mountain Retreat",
    image: mountainImg,
    places: 10,
    duration: "4-5 days",
    description: "Scenic peaks, adventure trails, and breathtaking natural landscapes",
    rating: 4.9,
    category: "Mountain",
  },
];

const FeaturedDestinations = () => {
  return (
    <section className="py-24 bg-gradient-to-b from-muted/30 to-background relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-1/2 left-0 w-64 h-64 bg-accent/10 rounded-full blur-3xl" />
      <div className="absolute top-1/4 right-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16 animate-fade-in">
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent text-sm font-medium mb-6">
            <MapPin className="h-4 w-4" />
            Explore India
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6 bg-gradient-to-r from-primary via-accent to-adventure bg-clip-text text-transparent">
            Popular Destinations
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Discover amazing places across India with AI-optimized routes and personalized recommendations
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {destinations.map((destination, index) => (
            <Link 
              key={destination.id} 
              to="/destinations" 
              className="group"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <Card className="overflow-hidden border-2 hover:border-primary/50 transition-all duration-300 hover:shadow-2xl h-full">
                <div className="relative h-72 overflow-hidden">
                  <img
                    src={destination.image}
                    alt={destination.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
                  
                  {/* Category Badge */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1.5 rounded-full bg-background/90 backdrop-blur-sm text-sm font-medium text-foreground">
                      {destination.category}
                    </span>
                  </div>
                  
                  {/* Rating Badge */}
                  <div className="absolute top-4 right-4">
                    <span className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-accent/90 text-accent-foreground text-sm font-semibold">
                      <Star className="h-3.5 w-3.5 fill-current" />
                      {destination.rating}
                    </span>
                  </div>
                  
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-2xl md:text-3xl font-display font-bold text-foreground mb-2">
                      {destination.name}
                    </h3>
                    <p className="text-base text-muted-foreground line-clamp-2">{destination.description}</p>
                  </div>
                </div>
                <CardContent className="p-5">
                  <div className="flex items-center justify-between text-base">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-5 w-5 text-primary" />
                      <span className="font-medium">{destination.places} places</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Clock className="h-5 w-5 text-accent" />
                      <span className="font-medium">{destination.duration}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link to="/destinations">
            <Button size="lg" variant="outline" className="rounded-xl px-8 py-6 text-lg border-2 hover:bg-primary hover:text-primary-foreground transition-all">
              View All 200+ Destinations
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedDestinations;
