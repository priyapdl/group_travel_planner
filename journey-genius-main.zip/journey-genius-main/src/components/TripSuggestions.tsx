import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend } from "recharts";
import { Loader2, Sparkles, MapPin, Clock, DollarSign, Navigation, Compass, TrendingUp, Car, Zap, Wallet, Info, Star, Image } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import heroImage from "@/assets/ai-suggestions-hero.jpg";
import routeIllustration from "@/assets/route-planning-illustration.jpg";
import travelTipsIcon from "@/assets/travel-tips-icon.jpg";
import routeComparisonImage from "@/assets/route-comparison.jpg";

interface TripSuggestionsProps {
  tripId: string;
  tripName: string;
  tripDescription?: string;
  duration?: number;
  budget?: number;
  startDate?: string;
}

interface DestinationImage {
  name: string;
  imageUrl: string;
  category: string;
  rating: number;
}

const TripSuggestions = ({ 
  tripId, 
  tripName, 
  tripDescription, 
  duration, 
  budget,
  startDate 
}: TripSuggestionsProps) => {
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<string>("");
  const [existingDestinations, setExistingDestinations] = useState<string[]>([]);
  const [destinationImages, setDestinationImages] = useState<DestinationImage[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    fetchExistingDestinations();
    fetchDestinationImages();
  }, [tripId]);

  const fetchExistingDestinations = async () => {
    try {
      const { data, error } = await supabase
        .from("trip_destinations")
        .select("destinations(name)")
        .eq("trip_id", tripId);

      if (error) throw error;
      
      const names = data
        ?.map((td: any) => td.destinations?.name)
        .filter(Boolean) || [];
      
      setExistingDestinations(names);
    } catch (error) {
      console.error("Error fetching destinations:", error);
    }
  };

  const fetchDestinationImages = async () => {
    try {
      const { data, error } = await supabase
        .from("destinations")
        .select("name, images, category, rating")
        .limit(12);

      if (error) throw error;
      
      const images: DestinationImage[] = (data || []).map((dest: any) => ({
        name: dest.name,
        imageUrl: Array.isArray(dest.images) && dest.images.length > 0 
          ? dest.images[0] 
          : '/placeholder.svg',
        category: dest.category || 'Destination',
        rating: dest.rating || 4.5,
      }));
      
      setDestinationImages(images);
    } catch (error) {
      console.error("Error fetching destination images:", error);
    }
  };

  const generateSuggestions = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('trip-suggestions', {
        body: {
          tripDetails: {
            name: tripName,
            description: tripDescription,
            duration: duration || 7,
            budget,
            startDate,
          },
          existingDestinations,
        },
      });

      if (error) throw error;

      if (data.error) {
        throw new Error(data.error);
      }

      setSuggestions(data.suggestions);
      
      toast({
        title: "Suggestions generated!",
        description: "AI has analyzed your trip and provided recommendations.",
      });
    } catch (error: any) {
      console.error("Error generating suggestions:", error);
      toast({
        variant: "destructive",
        title: "Failed to generate suggestions",
        description: error.message || "Please try again later.",
      });
    } finally {
      setLoading(false);
    }
  };

  const parseSuggestions = () => {
    if (!suggestions) return null;
    
    const sections = suggestions.split(/(?=##\s)/g).filter(Boolean);
    
    return sections.map((section, idx) => {
      const lines = section.split('\n').filter(Boolean);
      const title = lines[0]?.replace(/^##\s*/, '').trim() || '';
      const content = lines.slice(1).join('\n').trim();
      
      return { title, content, id: idx };
    });
  };

  const parseRouteComparison = () => {
    if (!suggestions) return null;
    
    // Find the Route Comparison section
    const routeSection = suggestions.match(/##\s*Route Comparison[\s\S]*?(?=##|$)/i);
    if (!routeSection) return null;

    const routes: Array<{
      name: string;
      description: string;
      time?: string;
      distance?: string;
      cost?: string;
      highlights?: string[];
      transport?: string;
    }> = [];

    // Parse individual routes (looking for bold route names or numbered routes)
    const routeMatches = routeSection[0].matchAll(/(?:\*\*|\d\.)\s*([^:\n]+)(?::|[\s\S]*?)-?\s*(?:Description|Route)?[:\s]*([^\n]+)[\s\S]*?(?:Travel Time|Time)[:\s]*([^\n]+)[\s\S]*?(?:Distance)[:\s]*([^\n]+)[\s\S]*?(?:Cost|Budget)[:\s]*([^\n]+)/gi);

    for (const match of routeMatches) {
      const name = match[1]?.trim();
      const description = match[2]?.trim();
      const time = match[3]?.trim();
      const distance = match[4]?.trim();
      const cost = match[5]?.trim();

      if (name) {
        routes.push({ name, description, time, distance, cost });
      }
    }

    return routes.length > 0 ? routes : null;
  };

  const prepareRouteChartData = (routes: any[]) => {
    return routes.map(route => {
      const timeValue = parseFloat(route.time?.match(/[\d.]+/)?.[0] || '0');
      const distValue = parseFloat(route.distance?.match(/[\d.]+/)?.[0] || '0');
      const costValue = parseFloat(route.cost?.match(/[\d.]+/)?.[0] || '0');
      
      return {
        name: route.name.split(' ')[0], // Short name for chart
        time: timeValue,
        distance: distValue,
        cost: costValue / 100, // Scale down cost for better visualization
      };
    });
  };

  const parseDestinationDetails = () => {
    if (!suggestions) return [];
    
    const destinations: any[] = [];
    const sections = parseSuggestions();
    
    sections?.forEach(section => {
      if (section.title && !section.title.toLowerCase().includes('route') && 
          !section.title.toLowerCase().includes('comparison') &&
          section.content.length < 500) {
        destinations.push({ 
          title: section.title, 
          content: section.content.slice(0, 200) 
        });
      }
    });
    
    return destinations.slice(0, 8);
  };

  const parsedSuggestions = parseSuggestions();
  const routeOptions = parseRouteComparison();
  const chartData = routeOptions ? prepareRouteChartData(routeOptions) : [];
  const destinationDetails = parseDestinationDetails();

  return (
    <div className="space-y-10">
      {/* Hero Section */}
      <Card className="border-0 overflow-hidden bg-gradient-to-br from-primary/10 via-accent/10 to-adventure/10">
        <div className="relative h-72 md:h-96">
          <img 
            src={heroImage} 
            alt="AI Trip Planning" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-6 w-6 text-primary" />
              <span className="text-base font-medium text-primary uppercase tracking-wide">AI-Powered Insights</span>
            </div>
            <h2 className="text-3xl md:text-5xl lg:text-6xl font-display font-bold text-foreground mb-3">
              Smart Trip Suggestions
            </h2>
            <p className="text-muted-foreground text-lg md:text-xl max-w-2xl leading-relaxed">
              Get personalized destination recommendations, optimal routes, and expert travel tips tailored to your preferences
            </p>
          </div>
        </div>
      </Card>

      {/* Trip Details Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {duration && (
          <Card className="border-2 border-primary/20 hover:shadow-lg transition-shadow">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-start gap-4">
                <div className="p-3 md:p-4 rounded-xl bg-primary/10">
                  <Clock className="h-6 w-6 md:h-7 md:w-7 text-primary" />
                </div>
                <div>
                  <p className="text-base text-muted-foreground mb-1">Trip Duration</p>
                  <p className="text-2xl md:text-3xl font-display font-bold text-foreground">{duration} days</p>
                  <p className="text-sm text-muted-foreground mt-1">Optimal itinerary planning</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        {budget && (
          <Card className="border-2 border-adventure/20 hover:shadow-lg transition-shadow">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-start gap-4">
                <div className="p-3 md:p-4 rounded-xl bg-adventure/10">
                  <DollarSign className="h-6 w-6 md:h-7 md:w-7 text-adventure" />
                </div>
                <div>
                  <p className="text-base text-muted-foreground mb-1">Total Budget</p>
                  <p className="text-2xl md:text-3xl font-display font-bold text-foreground">₹{budget.toLocaleString('en-IN')}</p>
                  <p className="text-sm text-muted-foreground mt-1">Cost-optimized suggestions</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        {existingDestinations.length > 0 && (
          <Card className="border-2 border-accent/20 hover:shadow-lg transition-shadow">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-start gap-4">
                <div className="p-3 md:p-4 rounded-xl bg-accent/10">
                  <MapPin className="h-6 w-6 md:h-7 md:w-7 text-accent" />
                </div>
                <div>
                  <p className="text-base text-muted-foreground mb-1">Destinations</p>
                  <p className="text-2xl md:text-3xl font-display font-bold text-foreground">{existingDestinations.length}</p>
                  <p className="text-sm text-muted-foreground mt-1">Places to explore</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Destination Images Preview */}
      {!suggestions && destinationImages.length > 0 && (
        <Card className="border-2">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Image className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-xl md:text-2xl font-display">Explore Destinations</CardTitle>
                <CardDescription className="text-base">Popular places you can add to your trip</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {destinationImages.slice(0, 8).map((dest, idx) => (
                <div key={idx} className="relative group rounded-xl overflow-hidden aspect-[4/3] cursor-pointer">
                  <img 
                    src={dest.imageUrl} 
                    alt={dest.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/placeholder.svg';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent" />
                  <div className="absolute top-2 right-2">
                    <span className="flex items-center gap-1 px-2 py-1 rounded-full bg-accent/90 text-accent-foreground text-xs font-semibold">
                      <Star className="h-3 w-3 fill-current" />
                      {dest.rating}
                    </span>
                  </div>
                  <div className="absolute bottom-2 left-2 right-2">
                    <p className="text-sm font-semibold text-foreground truncate">{dest.name}</p>
                    <p className="text-xs text-muted-foreground">{dest.category}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Generate Button */}
      {!suggestions && (
        <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
          <CardContent className="p-8 md:p-12 text-center">
            <div className="max-w-lg mx-auto space-y-6">
              <div className="w-20 h-20 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center">
                <Sparkles className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-2xl md:text-3xl font-display font-bold">Ready to discover?</h3>
              <p className="text-muted-foreground text-lg leading-relaxed">
                Our AI will analyze your trip details and generate personalized recommendations with optimal routes
              </p>
              <Button 
                onClick={generateSuggestions} 
                disabled={loading}
                className="w-full max-w-sm text-lg py-6 rounded-xl"
                size="lg"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Analyzing Your Trip...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-5 w-5" />
                    Generate Smart Suggestions
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* AI Suggestions Display */}
      {suggestions && (
        <div className="space-y-6">
          {/* Route Comparison Section */}
          {routeOptions && routeOptions.length > 0 && (
            <div className="space-y-6">
              <Card className="border-0 overflow-hidden">
                <div className="relative h-48 md:h-56">
                  <img 
                    src={routeComparisonImage} 
                    alt="Route Comparison" 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/60 to-transparent" />
                  <div className="absolute inset-0 flex items-center px-6 md:px-12">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Navigation className="h-5 w-5 text-primary" />
                        <span className="text-sm font-medium text-primary uppercase tracking-wide">Smart Planning</span>
                      </div>
                      <h3 className="text-2xl md:text-3xl font-bold text-foreground">
                        Route Comparison
                      </h3>
                      <p className="text-muted-foreground max-w-xl">
                        Visual comparison to help you choose the best route
                      </p>
                    </div>
                  </div>
                </div>
              </Card>

              <Tabs defaultValue="chart" className="w-full">
                <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-6">
                  <TabsTrigger value="chart">
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Chart View
                  </TabsTrigger>
                  <TabsTrigger value="table">
                    <Info className="h-4 w-4 mr-2" />
                    Table View
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="chart" className="space-y-6">
                  {chartData.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Route Metrics Comparison</CardTitle>
                        <CardDescription>Compare time, distance, and cost across all routes</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ChartContainer
                          config={{
                            time: {
                              label: "Time (hrs)",
                              color: "hsl(var(--primary))",
                            },
                            distance: {
                              label: "Distance (km)",
                              color: "hsl(var(--chart-2))",
                            },
                            cost: {
                              label: "Cost (₹100s)",
                              color: "hsl(var(--chart-3))",
                            },
                          }}
                          className="h-[350px]"
                        >
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={chartData}>
                              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                              <XAxis dataKey="name" className="text-sm" />
                              <YAxis className="text-sm" />
                              <ChartTooltip content={<ChartTooltipContent />} />
                              <Legend />
                              <Bar dataKey="time" fill="hsl(var(--primary))" name="Time (hrs)" radius={[8, 8, 0, 0]} />
                              <Bar dataKey="distance" fill="hsl(var(--chart-2))" name="Distance (km)" radius={[8, 8, 0, 0]} />
                              <Bar dataKey="cost" fill="hsl(var(--chart-3))" name="Cost (₹100s)" radius={[8, 8, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </ChartContainer>
                      </CardContent>
                    </Card>
                  )}

                  <div className="grid md:grid-cols-3 gap-4">
                    {routeOptions.map((route, idx) => (
                      <Card key={idx} className="border-2 hover:border-primary/30 transition-all">
                        <CardHeader>
                          <div className="flex items-center justify-between mb-2">
                            <CardTitle className="text-lg">{route.name}</CardTitle>
                            <Badge variant={idx === 0 ? "default" : "outline"}>
                              {idx === 0 ? "Best" : `Alt ${idx}`}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-2">
                          {route.time && (
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Time:</span>
                              <span className="font-semibold">{route.time}</span>
                            </div>
                          )}
                          {route.distance && (
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Distance:</span>
                              <span className="font-semibold">{route.distance}</span>
                            </div>
                          )}
                          {route.cost && (
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Cost:</span>
                              <span className="font-semibold">{route.cost}</span>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="table">
                  <Card>
                    <CardHeader>
                      <CardTitle>Detailed Route Comparison</CardTitle>
                      <CardDescription>All route details in one table</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-[200px]">Route</TableHead>
                              <TableHead>Travel Time</TableHead>
                              <TableHead>Distance</TableHead>
                              <TableHead>Cost</TableHead>
                              <TableHead>Transport</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {routeOptions.map((route, idx) => (
                              <TableRow key={idx}>
                                <TableCell className="font-medium">
                                  <div className="flex items-center gap-2">
                                    {route.name}
                                    {idx === 0 && <Badge variant="default" className="ml-2">Best</Badge>}
                                  </div>
                                </TableCell>
                                <TableCell>{route.time || 'N/A'}</TableCell>
                                <TableCell>{route.distance || 'N/A'}</TableCell>
                                <TableCell>{route.cost || 'N/A'}</TableCell>
                                <TableCell>{route.transport || 'N/A'}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          )}

          {/* Route Planning Visual */}
          <Card className="border-0 overflow-hidden">
            <div className="relative h-48 md:h-64">
              <img 
                src={routeIllustration} 
                alt="Route Planning" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/50 to-transparent" />
              <div className="absolute inset-0 flex items-center px-6 md:px-12">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Compass className="h-5 w-5 text-primary" />
                    <span className="text-sm font-medium text-primary uppercase tracking-wide">Your Journey</span>
                  </div>
                  <h3 className="text-2xl md:text-3xl font-bold text-foreground">
                    Detailed Travel Plan
                  </h3>
                </div>
              </div>
            </div>
          </Card>

          {/* Parsed Suggestions */}
          {parsedSuggestions && parsedSuggestions.length > 0 ? (
            <div className="space-y-6">
              <div className="text-center">
                <h3 className="text-2xl md:text-3xl font-bold mb-2">AI-Powered Travel Insights</h3>
                <p className="text-muted-foreground">Organized recommendations to plan your perfect trip</p>
              </div>

              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-3 mb-8">
                  <TabsTrigger value="overview" className="text-base">Overview</TabsTrigger>
                  <TabsTrigger value="destinations" className="text-base">Destinations</TabsTrigger>
                  <TabsTrigger value="details" className="text-base">Full Details</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-6">
                  <Card className="border-2">
                    <CardHeader>
                      <CardTitle className="text-xl md:text-2xl font-display">Trip Summary</CardTitle>
                      <CardDescription className="text-base">Quick overview of key recommendations</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="w-1/3 text-base font-semibold">Category</TableHead>
                            <TableHead className="text-base font-semibold">Details</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {parsedSuggestions.slice(0, 6).map((section) => (
                            <TableRow key={section.id}>
                              <TableCell className="font-medium text-base">{section.title}</TableCell>
                              <TableCell className="text-base text-muted-foreground">
                                {section.content.slice(0, 150)}...
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="destinations" className="space-y-8">
                  {/* Destination Images Gallery */}
                  {destinationImages.length > 0 && (
                    <div className="space-y-6">
                      <div className="flex items-center gap-3">
                        <Image className="h-6 w-6 text-primary" />
                        <h4 className="text-xl md:text-2xl font-display font-semibold">Suggested Destinations</h4>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {destinationImages.slice(0, 8).map((dest, idx) => (
                          <Card key={idx} className="overflow-hidden group hover:shadow-xl transition-all duration-300 border-2 hover:border-primary/50">
                            <div className="relative h-40 overflow-hidden">
                              <img 
                                src={dest.imageUrl} 
                                alt={dest.name}
                                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = '/placeholder.svg';
                                }}
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent" />
                              <div className="absolute top-2 right-2">
                                <span className="flex items-center gap-1 px-2 py-1 rounded-full bg-accent/90 text-accent-foreground text-xs font-semibold">
                                  <Star className="h-3 w-3 fill-current" />
                                  {dest.rating}
                                </span>
                              </div>
                              <div className="absolute bottom-2 left-2 right-2">
                                <p className="text-sm font-semibold text-foreground truncate">{dest.name}</p>
                                <p className="text-xs text-muted-foreground">{dest.category}</p>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Destination Details from AI */}
                  <div className="grid md:grid-cols-2 gap-6">
                    {destinationDetails.map((dest, idx) => (
                      <Card key={idx} className="hover:shadow-lg transition-all duration-300 border-2 hover:border-primary/30">
                        <CardHeader className="pb-3">
                          <CardTitle className="text-lg md:text-xl font-display flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-primary/10">
                              <MapPin className="h-5 w-5 text-primary" />
                            </div>
                            {dest.title}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-base text-muted-foreground leading-relaxed">{dest.content}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="details" className="space-y-4">
                  {parsedSuggestions.map((section) => (
                    <Card key={section.id} className="hover:shadow-md transition-shadow">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                          {section.title.toLowerCase().includes('destination') && <MapPin className="h-5 w-5 text-primary" />}
                          {section.title.toLowerCase().includes('route') && <Navigation className="h-5 w-5 text-accent" />}
                          {(section.title.toLowerCase().includes('tip') || section.title.toLowerCase().includes('recommendation')) && <Compass className="h-5 w-5 text-adventure" />}
                          {!section.title.toLowerCase().includes('destination') && 
                           !section.title.toLowerCase().includes('route') && 
                           !section.title.toLowerCase().includes('tip') && 
                           !section.title.toLowerCase().includes('recommendation') && 
                           <TrendingUp className="h-5 w-5 text-primary" />}
                          {section.title}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="prose prose-sm max-w-none">
                          <div className="whitespace-pre-wrap text-foreground leading-relaxed">
                            {section.content}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>
              </Tabs>
            </div>
          ) : (
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Sparkles className="h-5 w-5 text-primary" />
                  AI Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  <div className="whitespace-pre-wrap text-foreground leading-relaxed">
                    {suggestions}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Travel Tips Card */}
          <Card className="border-2 border-adventure/20 bg-gradient-to-br from-adventure/5 to-transparent">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <img 
                  src={travelTipsIcon} 
                  alt="Travel Tips" 
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h4 className="font-semibold text-lg mb-2 flex items-center gap-2">
                    <Compass className="h-5 w-5 text-adventure" />
                    Pro Travel Tips
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    These AI-generated suggestions are optimized based on your trip duration, budget, and selected destinations. Consider local weather, peak seasons, and booking in advance for the best experience.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default TripSuggestions;