import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { MapPin, Users, Sparkles, Star, ArrowRight } from "lucide-react";
import heroImage from "@/assets/hero-travel.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Group of travelers celebrating at mountain peak"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/90 via-primary/70 to-accent/80" />
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 text-center z-10 pt-20">
        <div className="max-w-5xl mx-auto space-y-10 animate-fade-in">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-background/20 backdrop-blur-sm border border-background/30 text-primary-foreground">
            <Sparkles className="h-5 w-5" />
            <span className="text-base font-medium">AI-Powered Travel Planning</span>
          </div>

          {/* Main Heading */}
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold text-primary-foreground leading-tight">
            Plan Perfect Group
            <br />
            <span className="bg-gradient-to-r from-accent via-secondary to-accent bg-clip-text text-transparent">
              Adventures Together
            </span>
          </h1>

          {/* Subheading */}
          <p className="text-xl md:text-2xl lg:text-3xl text-primary-foreground/90 max-w-3xl mx-auto font-light leading-relaxed">
            Smart route optimization, AI-powered suggestions, and seamless collaboration
            for unforgettable group travel experiences across India.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-5 justify-center items-center pt-4">
            <Link to="/auth">
              <Button
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground shadow-lg hover:shadow-xl transition-all text-lg px-8 py-6 rounded-xl"
              >
                <Users className="mr-2 h-5 w-5" />
                Start Planning Free
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/destinations">
              <Button
                size="lg"
                variant="outline"
                className="bg-background/20 backdrop-blur-sm border-2 border-background/40 text-primary-foreground hover:bg-background/30 text-lg px-8 py-6 rounded-xl"
              >
                <MapPin className="mr-2 h-5 w-5" />
                Explore 200+ Destinations
              </Button>
            </Link>
          </div>

          {/* Trust Badges */}
          <div className="flex flex-wrap gap-6 justify-center items-center pt-8">
            <div className="flex items-center gap-2 text-primary-foreground/90">
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="w-10 h-10 rounded-full bg-background/30 border-2 border-background/50 flex items-center justify-center text-sm font-bold">
                    {i}K+
                  </div>
                ))}
              </div>
              <span className="text-base font-medium ml-2">Happy Travelers</span>
            </div>
            <div className="h-8 w-px bg-background/30 hidden sm:block" />
            <div className="flex items-center gap-2 text-primary-foreground/90">
              <Star className="h-5 w-5 fill-accent text-accent" />
              <span className="text-base font-medium">4.9/5 Rating</span>
            </div>
          </div>

          {/* Feature Pills */}
          <div className="flex flex-wrap gap-4 justify-center pt-6">
            {["Route Optimization", "AI Suggestions", "GPS Integration", "Expense Splitting", "Group Collaboration"].map(
              (feature) => (
                <div
                  key={feature}
                  className="px-5 py-2.5 rounded-full bg-background/15 backdrop-blur-sm border border-background/25 text-primary-foreground text-base font-medium hover:bg-background/25 transition-colors cursor-default"
                >
                  {feature}
                </div>
              )
            )}
          </div>
        </div>
      </div>

      {/* Decorative gradient orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent/30 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
    </section>
  );
};

export default Hero;
