import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Star, Clock, IndianRupee } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface Destination {
  id: string;
  name: string;
  description: string;
  images: any;
  rating: number;
  category: string;
  entry_fee: number;
  average_visit_duration: number;
  latitude: number;
  longitude: number;
}

interface DestinationGalleryProps {
  tripId?: string;
  limit?: number;
  category?: string;
}

const DestinationGallery = ({ tripId, limit = 6, category }: DestinationGalleryProps) => {
  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDestinations();
  }, [tripId, category]);

  const fetchDestinations = async () => {
    try {
      let query = supabase
        .from("destinations")
        .select("*")
        .order("rating", { ascending: false });

      if (category) {
        query = query.eq("category", category);
      }

      if (limit) {
        query = query.limit(limit);
      }

      const { data, error } = await query;

      if (error) throw error;
      setDestinations(data || []);
    } catch (error) {
      console.error("Error fetching destinations:", error);
    } finally {
      setLoading(false);
    }
  };

  const getImageUrl = (destination: Destination) => {
    if (destination.images && Array.isArray(destination.images) && destination.images.length > 0) {
      return destination.images[0];
    }
    return `https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800&auto=format&fit=crop&q=80`;
  };

  if (loading) {
    return (
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {Array.from({ length: limit }).map((_, idx) => (
          <Card key={idx} className="overflow-hidden">
            <Skeleton className="h-72 w-full" />
            <CardContent className="p-5 space-y-3">
              <Skeleton className="h-7 w-3/4" />
              <Skeleton className="h-5 w-full" />
              <Skeleton className="h-5 w-2/3" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (destinations.length === 0) {
    return (
      <Card className="border-2 border-dashed">
        <CardContent className="p-16 text-center">
          <MapPin className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <p className="text-xl text-muted-foreground">No destinations found</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
      {destinations.map((destination) => (
        <Card 
          key={destination.id} 
          className="overflow-hidden border-2 hover:border-primary/50 transition-all duration-300 hover:shadow-xl group cursor-pointer"
        >
          <div className="relative h-72 overflow-hidden">
            <img
              src={getImageUrl(destination)}
              alt={destination.name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              onError={(e) => {
                e.currentTarget.src = `https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800&auto=format&fit=crop&q=80`;
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/95 via-background/20 to-transparent" />
            <div className="absolute bottom-4 left-4 right-4">
              <h3 className="text-2xl md:text-3xl font-display font-bold text-foreground mb-2">
                {destination.name}
              </h3>
              {destination.category && (
                <span className="inline-block px-3 py-1.5 text-sm font-medium bg-primary/20 text-primary rounded-full">
                  {destination.category}
                </span>
              )}
            </div>
            {destination.rating && (
              <div className="absolute top-4 right-4 bg-accent/90 backdrop-blur-sm px-3 py-1.5 rounded-full flex items-center gap-1">
                <Star className="h-4 w-4 text-accent-foreground fill-accent-foreground" />
                <span className="text-sm font-bold text-accent-foreground">{destination.rating}</span>
              </div>
            )}
          </div>
          <CardContent className="p-5">
            {destination.description && (
              <p className="text-base text-muted-foreground mb-4 line-clamp-2 leading-relaxed">
                {destination.description}
              </p>
            )}
            <div className="flex items-center justify-between text-base">
              {destination.average_visit_duration && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="h-5 w-5 text-accent" />
                  <span className="font-medium">{destination.average_visit_duration}h visit</span>
                </div>
              )}
              {destination.entry_fee !== null && destination.entry_fee !== undefined && (
                <div className="flex items-center gap-1 text-adventure font-bold text-lg">
                  <IndianRupee className="h-5 w-5" />
                  <span>{destination.entry_fee === 0 ? 'Free' : destination.entry_fee.toLocaleString('en-IN')}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default DestinationGallery;
