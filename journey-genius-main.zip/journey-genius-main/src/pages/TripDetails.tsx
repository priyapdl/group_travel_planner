import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2, MapPin, Calendar, Wallet, Download, Sparkles, ClipboardList, Users, Receipt, Clock } from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import TripMembers from "@/components/TripMembers";
import ItineraryBuilder from "@/components/ItineraryBuilder";
import ExpenseManager from "@/components/ExpenseManager";
import TripSuggestions from "@/components/TripSuggestions";
import { generateTripPDF } from "@/utils/generateTripPDF";

interface Trip {
  id: string;
  name: string;
  description: string;
  start_date: string;
  end_date: string;
  budget: number;
  status: string;
  estimated_duration: number;
}

const statusColors: Record<string, string> = {
  planning: "bg-amber-500/10 text-amber-600 border-amber-500/30",
  confirmed: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30",
  ongoing: "bg-blue-500/10 text-blue-600 border-blue-500/30",
  completed: "bg-slate-500/10 text-slate-600 border-slate-500/30",
  cancelled: "bg-red-500/10 text-red-600 border-red-500/30",
};

const TripDetails = () => {
  const { id } = useParams<{ id: string }>();
  const [trip, setTrip] = useState<Trip | null>(null);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (id) {
      fetchTrip();
    }
  }, [id]);

  const fetchTrip = async () => {
    try {
      const { data, error } = await supabase
        .from("trips")
        .select("*")
        .eq("id", id)
        .single();

      if (error) throw error;
      setTrip(data);
    } catch (error) {
      console.error("Error fetching trip:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleExportPDF = async () => {
    if (!trip || !id) return;
    setExporting(true);

    try {
      const { data: itinerary } = await supabase
        .from("itinerary")
        .select("*")
        .eq("trip_id", id)
        .order("day_number", { ascending: true });

      const { data: expenses } = await supabase
        .from("expenses")
        .select("*")
        .eq("trip_id", id)
        .order("date", { ascending: true });

      const { data: members } = await supabase
        .from("trip_members")
        .select("*")
        .eq("trip_id", id);

      generateTripPDF(trip, itinerary || [], expenses || [], members || []);

      toast({
        title: "PDF Generated",
        description: "Your trip itinerary has been downloaded",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Export Failed",
        description: error.message || "Failed to generate PDF",
      });
    } finally {
      setExporting(false);
    }
  };

  const getDuration = () => {
    if (trip?.start_date && trip?.end_date) {
      return differenceInDays(new Date(trip.end_date), new Date(trip.start_date)) + 1;
    }
    return trip?.estimated_duration || 0;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-lg text-muted-foreground">Loading trip details...</p>
        </div>
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <Card className="border-2 p-8 text-center max-w-md">
          <MapPin className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-3xl font-display font-bold mb-3">Trip not found</h2>
          <p className="text-muted-foreground mb-6">The trip you're looking for doesn't exist or has been removed.</p>
          <Link to="/trips">
            <Button size="lg" className="font-semibold">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back to trips
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-muted/30 via-background to-primary/5">
      {/* Header */}
      <header className="bg-background/80 backdrop-blur-md border-b border-border sticky top-0 z-50">
        <div className="container mx-auto px-4 py-5">
          <Link to="/trips" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-lg font-medium group">
            <ArrowLeft className="h-5 w-5 group-hover:-translate-x-1 transition-transform" />
            Back to Trips
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-10">
        {/* Trip Header Card */}
        <Card className="mb-8 border-2 bg-gradient-to-br from-background via-background to-primary/5 overflow-hidden">
          <CardHeader className="pb-6">
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <Badge 
                    variant="outline" 
                    className={`text-sm font-medium px-3 py-1 capitalize ${statusColors[trip.status] || ''}`}
                  >
                    {trip.status}
                  </Badge>
                </div>
                <CardTitle className="text-4xl md:text-5xl font-display mb-4 bg-gradient-to-r from-foreground to-foreground/80 bg-clip-text">
                  {trip.name}
                </CardTitle>
                {trip.description && (
                  <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl">
                    {trip.description}
                  </p>
                )}
              </div>
              <Button
                variant="outline"
                size="lg"
                onClick={handleExportPDF}
                disabled={exporting}
                className="gap-2 font-semibold shrink-0"
              >
                {exporting ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <Download className="h-5 w-5" />
                )}
                Export PDF
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {trip.start_date && (
                <div className="flex items-center gap-4 p-4 rounded-xl bg-primary/5 border border-primary/10">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center">
                    <Calendar className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Travel Dates</p>
                    <p className="text-lg font-semibold">
                      {format(new Date(trip.start_date), "MMM d")}
                      {trip.end_date && ` - ${format(new Date(trip.end_date), "MMM d, yyyy")}`}
                    </p>
                  </div>
                </div>
              )}
              
              {trip.budget && (
                <div className="flex items-center gap-4 p-4 rounded-xl bg-adventure/5 border border-adventure/10">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-adventure to-adventure/80 flex items-center justify-center">
                    <Wallet className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Trip Budget</p>
                    <p className="text-lg font-semibold">₹{trip.budget.toLocaleString('en-IN')}</p>
                  </div>
                </div>
              )}
              
              <div className="flex items-center gap-4 p-4 rounded-xl bg-accent/5 border border-accent/10">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent to-accent/80 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-accent-foreground" />
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Duration</p>
                  <p className="text-lg font-semibold">{getDuration()} {getDuration() === 1 ? 'day' : 'days'}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs Section */}
        <Tabs defaultValue="suggestions" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4 h-14 p-1 bg-muted/50">
            <TabsTrigger value="suggestions" className="text-base font-medium gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <Sparkles className="h-4 w-4" />
              <span className="hidden sm:inline">AI Suggestions</span>
              <span className="sm:hidden">AI</span>
            </TabsTrigger>
            <TabsTrigger value="itinerary" className="text-base font-medium gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <ClipboardList className="h-4 w-4" />
              <span className="hidden sm:inline">Itinerary</span>
              <span className="sm:hidden">Plan</span>
            </TabsTrigger>
            <TabsTrigger value="members" className="text-base font-medium gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Members</span>
              <span className="sm:hidden">Team</span>
            </TabsTrigger>
            <TabsTrigger value="expenses" className="text-base font-medium gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <Receipt className="h-4 w-4" />
              <span className="hidden sm:inline">Expenses</span>
              <span className="sm:hidden">Cost</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="suggestions" className="space-y-4 animate-fade-in">
            <TripSuggestions
              tripId={id!}
              tripName={trip.name}
              tripDescription={trip.description}
              duration={trip.estimated_duration}
              budget={trip.budget}
              startDate={trip.start_date}
            />
          </TabsContent>

          <TabsContent value="itinerary" className="space-y-4 animate-fade-in">
            <ItineraryBuilder tripId={id!} />
          </TabsContent>

          <TabsContent value="members" className="space-y-4 animate-fade-in">
            <TripMembers tripId={id!} />
          </TabsContent>

          <TabsContent value="expenses" className="space-y-4 animate-fade-in">
            <ExpenseManager tripId={id!} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default TripDetails;
