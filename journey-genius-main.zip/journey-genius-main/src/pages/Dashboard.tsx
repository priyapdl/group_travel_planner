import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { User } from "@supabase/supabase-js";
import { Compass, LogOut, MapPin, History, Settings, Sparkles, Route, Users } from "lucide-react";
import { Link } from "react-router-dom";

const Dashboard = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Check for session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        setUser(session.user);
      } else {
        navigate("/auth");
      }
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session?.user) {
        setUser(session.user);
      } else {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    toast({
      title: "Signed out",
      description: "You have been successfully signed out.",
    });
    navigate("/");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="animate-spin">
          <Compass className="h-10 w-10 text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-muted/30 via-background to-primary/5">
      {/* Header */}
      <header className="bg-background/80 backdrop-blur-md border-b border-border sticky top-0 z-50">
        <div className="container mx-auto px-4 py-5 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-primary to-accent transition-all duration-300 group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/25">
              <Compass className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-2xl font-display font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              GroupTravel Planner
            </span>
          </Link>
          <Button variant="outline" size="lg" onClick={handleSignOut} className="gap-2 font-medium">
            <LogOut className="h-5 w-5" />
            Sign Out
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="mb-12">
          <h1 className="text-5xl md:text-6xl font-display font-bold mb-4 bg-gradient-to-r from-foreground via-foreground to-primary bg-clip-text text-transparent">
            Welcome back!
          </h1>
          <p className="text-xl text-muted-foreground">{user?.email}</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <Link to="/trips/create" className="group">
            <Card className="border-2 border-primary/20 hover:border-primary/50 transition-all duration-300 cursor-pointer h-full bg-gradient-to-br from-primary/5 to-transparent hover:shadow-xl hover:shadow-primary/10 hover:-translate-y-1">
              <CardHeader className="pb-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <MapPin className="h-7 w-7 text-primary-foreground" />
                </div>
                <CardTitle className="text-2xl font-display">Plan New Trip</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-base text-muted-foreground mb-6 leading-relaxed">
                  Start planning your next adventure with AI-powered route optimization and smart suggestions.
                </p>
                <Button size="lg" className="w-full text-base font-semibold">
                  Create Trip
                </Button>
              </CardContent>
            </Card>
          </Link>

          <Link to="/trips" className="group">
            <Card className="border-2 border-accent/20 hover:border-accent/50 transition-all duration-300 cursor-pointer h-full bg-gradient-to-br from-accent/5 to-transparent hover:shadow-xl hover:shadow-accent/10 hover:-translate-y-1">
              <CardHeader className="pb-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent to-accent/80 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <History className="h-7 w-7 text-accent-foreground" />
                </div>
                <CardTitle className="text-2xl font-display">My Trips</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-base text-muted-foreground mb-6 leading-relaxed">
                  View and manage your past and upcoming trips, track expenses, and collaborate with your group.
                </p>
                <Button variant="outline" size="lg" className="w-full text-base font-semibold">
                  View Trips
                </Button>
              </CardContent>
            </Card>
          </Link>

          <Card className="border-2 border-adventure/20 hover:border-adventure/50 transition-all duration-300 cursor-pointer bg-gradient-to-br from-adventure/5 to-transparent hover:shadow-xl hover:shadow-adventure/10 hover:-translate-y-1 group">
            <CardHeader className="pb-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-adventure to-adventure/80 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <Settings className="h-7 w-7 text-white" />
              </div>
              <CardTitle className="text-2xl font-display">Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-base text-muted-foreground mb-6 leading-relaxed">
                Customize your preferences, manage notifications, and update your account settings.
              </p>
              <Button variant="outline" size="lg" className="w-full text-base font-semibold">
                Manage
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Getting Started Guide */}
        <Card className="border-2 bg-gradient-to-br from-primary/5 via-background to-accent/5 overflow-hidden">
          <CardHeader className="pb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-primary-foreground" />
              </div>
              <CardTitle className="text-3xl font-display">Getting Started</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-8">
            <div className="flex items-start gap-5 group">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary/80 text-primary-foreground flex items-center justify-center text-xl font-bold shadow-lg shadow-primary/25 group-hover:scale-110 transition-transform">
                1
              </div>
              <div className="pt-1">
                <h3 className="text-xl font-semibold mb-2">Choose Your Destination</h3>
                <p className="text-base text-muted-foreground leading-relaxed">
                  Browse popular destinations across India or search for a specific location to start your journey.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-5 group">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-accent to-accent/80 text-accent-foreground flex items-center justify-center text-xl font-bold shadow-lg shadow-accent/25 group-hover:scale-110 transition-transform">
                2
              </div>
              <div className="pt-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-xl font-semibold">Get AI Recommendations</h3>
                  <Route className="h-5 w-5 text-accent" />
                </div>
                <p className="text-base text-muted-foreground leading-relaxed">
                  Receive smart suggestions for places to visit, optimal routes, and nearby restaurants and accommodations.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-5 group">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-adventure to-adventure/80 text-white flex items-center justify-center text-xl font-bold shadow-lg shadow-adventure/25 group-hover:scale-110 transition-transform">
                3
              </div>
              <div className="pt-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-xl font-semibold">Collaborate & Travel</h3>
                  <Users className="h-5 w-5 text-adventure" />
                </div>
                <p className="text-base text-muted-foreground leading-relaxed">
                  Invite your group, split expenses fairly, and enjoy a perfectly planned trip together.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default Dashboard;
