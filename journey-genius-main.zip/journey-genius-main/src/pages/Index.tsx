import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import FeaturedDestinations from "@/components/FeaturedDestinations";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <Features />
        <FeaturedDestinations />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
