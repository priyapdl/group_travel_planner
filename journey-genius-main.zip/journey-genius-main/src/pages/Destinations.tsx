import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, MapPin } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DestinationGallery from "@/components/DestinationGallery";

const Destinations = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);

  const categories = [
    { value: undefined, label: "All Destinations" },
    { value: "temple", label: "Temples" },
    { value: "beach", label: "Beaches" },
    { value: "mountain", label: "Mountains" },
    { value: "historical", label: "Historical" },
    { value: "nature", label: "Nature" },
    { value: "city", label: "Cities" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-muted/30 via-background to-muted/20">
      <header className="bg-background/80 backdrop-blur-md border-b border-border/50 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-5">
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-all duration-200 hover:gap-3 group text-base"
          >
            <ArrowLeft className="h-5 w-5 group-hover:scale-110 transition-transform" />
            <span className="font-medium">Back to Home</span>
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-16">
        <div className="text-center mb-16 animate-fade-in">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-primary/10 mb-6">
            <MapPin className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-bold mb-6 bg-gradient-to-r from-primary via-accent to-adventure bg-clip-text text-transparent">
            Explore Destinations
          </h1>
          <p className="text-muted-foreground text-lg md:text-xl max-w-3xl mx-auto leading-relaxed">
            Discover amazing places across India with detailed information, ratings, and beautiful imagery
          </p>
        </div>

        <Tabs defaultValue="all" className="space-y-10" onValueChange={(value) => setSelectedCategory(value === 'all' ? undefined : value)}>
          <TabsList className="grid w-full max-w-4xl mx-auto grid-cols-3 lg:grid-cols-7 mb-8 h-auto p-1">
            {categories.map((category) => (
              <TabsTrigger 
                key={category.value || 'all'} 
                value={category.value || 'all'}
                className="text-base py-3"
              >
                {category.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map((category) => (
            <TabsContent 
              key={category.value || 'all'} 
              value={category.value || 'all'}
              className="animate-fade-in"
            >
              <DestinationGallery category={category.value} limit={12} />
            </TabsContent>
          ))}
        </Tabs>
      </main>
    </div>
  );
};

export default Destinations;
