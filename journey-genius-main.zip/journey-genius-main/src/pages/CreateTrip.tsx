import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Calendar, DollarSign, Clock, ArrowLeft, Sparkles, Mountain, Church } from "lucide-react";
import { Link } from "react-router-dom";

type TripTemplate = {
  icon: React.ReactNode;
  name: string;
  description: string;
  data: {
    name: string;
    description: string;
    estimated_duration: string;
    budget: string;
  };
};

const CreateTrip = () => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    start_date: "",
    end_date: "",
    budget: "",
    estimated_duration: "",
  });
  
  const navigate = useNavigate();
  const { toast } = useToast();

  const templates: TripTemplate[] = [
    {
      icon: <Sparkles className="h-6 w-6" />,
      name: "Weekend Getaway",
      description: "Quick 2-3 day escape from routine",
      data: {
        name: "Weekend Getaway",
        description: "A short refreshing break to explore nearby destinations and unwind.",
        estimated_duration: "3",
        budget: "15000",
      },
    },
    {
      icon: <Mountain className="h-6 w-6" />,
      name: "Week-Long Tour",
      description: "Comprehensive 7-day adventure",
      data: {
        name: "Week-Long Tour",
        description: "A full week of exploration covering multiple destinations with balanced activities.",
        estimated_duration: "7",
        budget: "50000",
      },
    },
    {
      icon: <Church className="h-6 w-6" />,
      name: "Pilgrimage",
      description: "Spiritual journey to sacred places",
      data: {
        name: "Pilgrimage Trip",
        description: "A spiritual journey visiting temples, shrines, and sacred sites for peace and blessings.",
        estimated_duration: "5",
        budget: "25000",
      },
    },
  ];

  const applyTemplate = (template: TripTemplate) => {
    setFormData({
      ...formData,
      ...template.data,
    });
    toast({
      title: "Template applied!",
      description: `${template.name} template has been loaded. Customize as needed.`,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error("You must be logged in to create a trip");
      }

      const { data, error } = await supabase
        .from("trips")
        .insert({
          name: formData.name,
          description: formData.description || null,
          start_date: formData.start_date || null,
          end_date: formData.end_date || null,
          budget: formData.budget ? parseFloat(formData.budget) : null,
          estimated_duration: formData.estimated_duration ? parseInt(formData.estimated_duration) : null,
          user_id: user.id,
          status: "planning",
        })
        .select()
        .single();

      if (error) throw error;

      toast({
        title: "Trip created!",
        description: "Your trip has been successfully created.",
      });

      navigate(`/trips/${data.id}`);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to create trip",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-muted/30 via-background to-muted/20">
      <header className="bg-background/80 backdrop-blur-md border-b border-border/50 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <Link 
            to="/dashboard" 
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-all duration-200 hover:gap-3 group"
          >
            <ArrowLeft className="h-4 w-4 group-hover:scale-110 transition-transform" />
            <span className="font-medium">Back to Dashboard</span>
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 md:py-12">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8 animate-fade-in">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <MapPin className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary via-accent to-adventure bg-clip-text text-transparent">
              Create New Trip
            </h1>
            <p className="text-muted-foreground text-lg">
              Plan your next adventure with AI-powered route optimization
            </p>
          </div>

          {/* Quick Templates */}
          <div className="mb-8 animate-fade-in">
            <h2 className="text-xl font-semibold mb-4 text-center">
              Quick Start Templates
            </h2>
            <div className="grid md:grid-cols-3 gap-4">
              {templates.map((template) => (
                <Card
                  key={template.name}
                  className="cursor-pointer hover:border-primary hover:shadow-lg transition-all duration-300 group"
                  onClick={() => applyTemplate(template)}
                >
                  <CardContent className="p-6 text-center">
                    <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-3 group-hover:bg-primary/20 transition-colors">
                      {template.icon}
                    </div>
                    <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                      {template.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {template.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <Card className="border-0 shadow-2xl bg-card/95 backdrop-blur-sm animate-scale-in">
            <CardContent className="p-8 md:p-10">
              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="space-y-3">
                  <Label 
                    htmlFor="name" 
                    className="text-base font-semibold text-foreground flex items-center gap-2"
                  >
                    Trip Name <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="name"
                    placeholder="e.g., Summer Road Trip 2024"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="h-12 text-base border-2 focus:border-primary transition-colors"
                  />
                </div>

                <div className="space-y-3">
                  <Label 
                    htmlFor="description" 
                    className="text-base font-semibold text-foreground"
                  >
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="Tell us about your trip plans, destinations you'd like to visit, and any special requirements..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={4}
                    className="resize-none border-2 focus:border-primary transition-colors text-base"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label 
                      htmlFor="start_date" 
                      className="text-base font-semibold text-foreground flex items-center gap-2"
                    >
                      <Calendar className="h-4 w-4 text-primary" />
                      Start Date
                    </Label>
                    <Input
                      id="start_date"
                      type="date"
                      value={formData.start_date}
                      onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                      className="h-12 text-base border-2 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label 
                      htmlFor="end_date" 
                      className="text-base font-semibold text-foreground flex items-center gap-2"
                    >
                      <Calendar className="h-4 w-4 text-accent" />
                      End Date
                    </Label>
                    <Input
                      id="end_date"
                      type="date"
                      value={formData.end_date}
                      onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                      className="h-12 text-base border-2 focus:border-primary transition-colors"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label 
                      htmlFor="budget" 
                      className="text-base font-semibold text-foreground flex items-center gap-2"
                    >
                      <DollarSign className="h-4 w-4 text-adventure" />
                      Budget (₹)
                    </Label>
                    <Input
                      id="budget"
                      type="number"
                      placeholder="50000"
                      step="100"
                      value={formData.budget}
                      onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                      className="h-12 text-base border-2 focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label 
                      htmlFor="estimated_duration" 
                      className="text-base font-semibold text-foreground flex items-center gap-2"
                    >
                      <Clock className="h-4 w-4 text-primary" />
                      Duration (days)
                    </Label>
                    <Input
                      id="estimated_duration"
                      type="number"
                      placeholder="7"
                      value={formData.estimated_duration}
                      onChange={(e) => setFormData({ ...formData, estimated_duration: e.target.value })}
                      className="h-12 text-base border-2 focus:border-primary transition-colors"
                    />
                  </div>
                </div>

                <div className="flex flex-col-reverse sm:flex-row gap-4 pt-6">
                  <Button
                    type="button"
                    variant="outline"
                    size="lg"
                    className="flex-1 h-12 text-base border-2 hover:bg-muted transition-all duration-200"
                    onClick={() => navigate("/dashboard")}
                    disabled={loading}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    size="lg"
                    className="flex-1 h-12 text-base bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 transition-all duration-200 shadow-lg hover:shadow-xl"
                    disabled={loading}
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <span className="animate-spin">⏳</span>
                        Creating...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <MapPin className="h-5 w-5" />
                        Create Trip
                      </span>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          <div className="mt-6 text-center text-sm text-muted-foreground animate-fade-in">
            <p>Need help? Check out our <span className="text-primary cursor-pointer hover:underline">trip planning guide</span></p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default CreateTrip;
