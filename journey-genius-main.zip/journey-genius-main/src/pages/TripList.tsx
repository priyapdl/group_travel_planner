import { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MapPin, Calendar, ArrowLeft, Plus, Loader2, Trash2, Wallet, Search, Filter, X, ArrowUpDown, ArrowUp, ArrowDown, BarChart3 } from "lucide-react";
import TripStatsDashboard from "@/components/TripStatsDashboard";
import { format, differenceInDays, isAfter, isBefore, parseISO } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface Trip {
  id: string;
  name: string;
  description: string;
  start_date: string;
  end_date: string;
  status: string;
  created_at: string;
  budget: number;
}

type SortField = "name" | "start_date" | "budget" | "status" | "created_at";
type SortDirection = "asc" | "desc";

const statusColors: Record<string, string> = {
  planning: "bg-amber-500/10 text-amber-600 border-amber-500/30",
  confirmed: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30",
  ongoing: "bg-blue-500/10 text-blue-600 border-blue-500/30",
  completed: "bg-slate-500/10 text-slate-600 border-slate-500/30",
  cancelled: "bg-red-500/10 text-red-600 border-red-500/30",
};

const statusOrder = ["planning", "confirmed", "ongoing", "completed", "cancelled"];

const statusOptions = [
  { value: "all", label: "All Status" },
  { value: "planning", label: "Planning" },
  { value: "confirmed", label: "Confirmed" },
  { value: "ongoing", label: "Ongoing" },
  { value: "completed", label: "Completed" },
  { value: "cancelled", label: "Cancelled" },
];

const dateFilterOptions = [
  { value: "all", label: "All Dates" },
  { value: "upcoming", label: "Upcoming" },
  { value: "past", label: "Past" },
  { value: "this_month", label: "This Month" },
];

const sortOptions = [
  { value: "created_at", label: "Date Created" },
  { value: "name", label: "Name" },
  { value: "start_date", label: "Trip Date" },
  { value: "budget", label: "Budget" },
  { value: "status", label: "Status" },
];

const TripList = () => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [selectedTrips, setSelectedTrips] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("all");
  const [sortField, setSortField] = useState<SortField>("created_at");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
  const [showBulkDeleteDialog, setShowBulkDeleteDialog] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchTrips();
  }, []);

  const fetchTrips = async () => {
    try {
      const { data, error } = await supabase
        .from("trips")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setTrips(data || []);
    } catch (error) {
      console.error("Error fetching trips:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredAndSortedTrips = useMemo(() => {
    // First filter
    const filtered = trips.filter((trip) => {
      // Search filter
      const matchesSearch = 
        trip.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (trip.description && trip.description.toLowerCase().includes(searchQuery.toLowerCase()));

      // Status filter
      const matchesStatus = statusFilter === "all" || trip.status === statusFilter;

      // Date filter
      let matchesDate = true;
      const today = new Date();
      const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);

      if (dateFilter === "upcoming" && trip.start_date) {
        matchesDate = isAfter(parseISO(trip.start_date), today);
      } else if (dateFilter === "past" && trip.end_date) {
        matchesDate = isBefore(parseISO(trip.end_date), today);
      } else if (dateFilter === "this_month" && trip.start_date) {
        const tripStart = parseISO(trip.start_date);
        matchesDate = tripStart >= startOfMonth && tripStart <= endOfMonth;
      }

      return matchesSearch && matchesStatus && matchesDate;
    });

    // Then sort
    const sorted = [...filtered].sort((a, b) => {
      let comparison = 0;

      switch (sortField) {
        case "name":
          comparison = a.name.localeCompare(b.name);
          break;
        case "start_date":
          if (!a.start_date && !b.start_date) comparison = 0;
          else if (!a.start_date) comparison = 1;
          else if (!b.start_date) comparison = -1;
          else comparison = new Date(a.start_date).getTime() - new Date(b.start_date).getTime();
          break;
        case "budget":
          const budgetA = a.budget || 0;
          const budgetB = b.budget || 0;
          comparison = budgetA - budgetB;
          break;
        case "status":
          comparison = statusOrder.indexOf(a.status) - statusOrder.indexOf(b.status);
          break;
        case "created_at":
        default:
          comparison = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
          break;
      }

      return sortDirection === "asc" ? comparison : -comparison;
    });

    return sorted;
  }, [trips, searchQuery, statusFilter, dateFilter, sortField, sortDirection]);

  const filteredTrips = filteredAndSortedTrips;

  const handleDeleteTrip = async (tripId: string, tripName: string) => {
    setDeletingId(tripId);
    try {
      const { error } = await supabase
        .from("trips")
        .delete()
        .eq("id", tripId);

      if (error) throw error;

      setTrips(trips.filter(trip => trip.id !== tripId));
      setSelectedTrips(prev => {
        const newSet = new Set(prev);
        newSet.delete(tripId);
        return newSet;
      });
      toast({
        title: "Trip Deleted",
        description: `"${tripName}" has been permanently deleted.`,
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Delete Failed",
        description: error.message || "Could not delete the trip.",
      });
    } finally {
      setDeletingId(null);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedTrips.size === 0) return;
    
    setBulkDeleting(true);
    try {
      const tripIds = Array.from(selectedTrips);
      const { error } = await supabase
        .from("trips")
        .delete()
        .in("id", tripIds);

      if (error) throw error;

      setTrips(trips.filter(trip => !selectedTrips.has(trip.id)));
      toast({
        title: "Trips Deleted",
        description: `${selectedTrips.size} trips have been permanently deleted.`,
      });
      setSelectedTrips(new Set());
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Bulk Delete Failed",
        description: error.message || "Could not delete the selected trips.",
      });
    } finally {
      setBulkDeleting(false);
      setShowBulkDeleteDialog(false);
    }
  };

  const toggleTripSelection = (tripId: string) => {
    setSelectedTrips(prev => {
      const newSet = new Set(prev);
      if (newSet.has(tripId)) {
        newSet.delete(tripId);
      } else {
        newSet.add(tripId);
      }
      return newSet;
    });
  };

  const toggleSelectAll = () => {
    if (selectedTrips.size === filteredTrips.length) {
      setSelectedTrips(new Set());
    } else {
      setSelectedTrips(new Set(filteredTrips.map(t => t.id)));
    }
  };

  const clearFilters = () => {
    setSearchQuery("");
    setStatusFilter("all");
    setDateFilter("all");
    setSortField("created_at");
    setSortDirection("desc");
  };

  const toggleSortDirection = () => {
    setSortDirection(prev => prev === "asc" ? "desc" : "asc");
  };

  const hasActiveFilters = searchQuery || statusFilter !== "all" || dateFilter !== "all";
  const hasCustomSort = sortField !== "created_at" || sortDirection !== "desc";

  const getDuration = (startDate: string, endDate: string) => {
    if (startDate && endDate) {
      return differenceInDays(new Date(endDate), new Date(startDate)) + 1;
    }
    return null;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-lg text-muted-foreground">Loading your trips...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-muted/30 via-background to-primary/5">
      {/* Header */}
      <header className="bg-background/80 backdrop-blur-md border-b border-border sticky top-0 z-50">
        <div className="container mx-auto px-4 py-5">
          <div className="flex items-center justify-between">
            <Link to="/dashboard" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-lg font-medium group">
              <ArrowLeft className="h-5 w-5 group-hover:-translate-x-1 transition-transform" />
              Back to Dashboard
            </Link>
            <Link to="/trips/create">
              <Button size="lg" className="gap-2 font-semibold">
                <Plus className="h-5 w-5" />
                New Trip
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-10">
        <div className="mb-10">
          <h1 className="text-5xl md:text-6xl font-display font-bold mb-4 bg-gradient-to-r from-foreground via-foreground to-primary bg-clip-text text-transparent">
            My Trips
          </h1>
          <p className="text-xl text-muted-foreground">View and manage all your travel plans</p>
        </div>

        {/* Statistics Dashboard */}
        <TripStatsDashboard trips={trips} />

        {trips.length === 0 ? (
          <Card className="border-2 border-dashed bg-gradient-to-br from-primary/5 to-transparent">
            <CardContent className="flex flex-col items-center justify-center py-20">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mb-6">
                <MapPin className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-2xl font-display font-bold mb-3">No trips yet</h3>
              <p className="text-lg text-muted-foreground mb-8 text-center max-w-md">
                Start planning your first adventure! Create a trip to get AI-powered route suggestions.
              </p>
              <Link to="/trips/create">
                <Button size="lg" className="gap-2 font-semibold">
                  <Plus className="h-5 w-5" />
                  Create Your First Trip
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Search and Filters */}
            <div className="mb-8 space-y-4">
              <div className="flex flex-col lg:flex-row gap-4">
                {/* Search */}
                <div className="relative flex-1">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    placeholder="Search trips by name or description..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-12 h-12 text-base"
                  />
                </div>

                {/* Status Filter */}
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-full lg:w-48 h-12">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Date Filter */}
                <Select value={dateFilter} onValueChange={setDateFilter}>
                  <SelectTrigger className="w-full lg:w-48 h-12">
                    <Calendar className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Filter by date" />
                  </SelectTrigger>
                  <SelectContent>
                    {dateFilterOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Sorting Controls */}
              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-muted-foreground">Sort by:</span>
                  <Select value={sortField} onValueChange={(value) => setSortField(value as SortField)}>
                    <SelectTrigger className="w-40 h-10">
                      <ArrowUpDown className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      {sortOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={toggleSortDirection}
                    className="h-10 w-10"
                    title={sortDirection === "asc" ? "Ascending" : "Descending"}
                  >
                    {sortDirection === "asc" ? (
                      <ArrowUp className="h-4 w-4" />
                    ) : (
                      <ArrowDown className="h-4 w-4" />
                    )}
                  </Button>
                </div>

                {(hasActiveFilters || hasCustomSort) && (
                  <Button
                    variant="ghost"
                    onClick={clearFilters}
                    className="h-10 gap-2 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-4 w-4" />
                    Reset All
                  </Button>
                )}
              </div>

              {/* Bulk Actions Bar */}
              <div className="flex items-center justify-between bg-muted/50 rounded-lg p-4">
                <div className="flex items-center gap-4">
                  <Checkbox
                    checked={filteredTrips.length > 0 && selectedTrips.size === filteredTrips.length}
                    onCheckedChange={toggleSelectAll}
                    id="select-all"
                  />
                  <label htmlFor="select-all" className="text-sm font-medium cursor-pointer">
                    {selectedTrips.size === filteredTrips.length && filteredTrips.length > 0 
                      ? "Deselect All" 
                      : "Select All"}
                  </label>
                  {selectedTrips.size > 0 && (
                    <Badge variant="secondary" className="font-medium">
                      {selectedTrips.size} selected
                    </Badge>
                  )}
                </div>

                {selectedTrips.size > 0 && (
                  <AlertDialog open={showBulkDeleteDialog} onOpenChange={setShowBulkDeleteDialog}>
                    <AlertDialogTrigger asChild>
                      <Button 
                        variant="destructive" 
                        size="sm" 
                        className="gap-2"
                        disabled={bulkDeleting}
                      >
                        {bulkDeleting ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Trash2 className="h-4 w-4" />
                        )}
                        Delete Selected ({selectedTrips.size})
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle className="text-2xl font-display">Delete {selectedTrips.size} Trips?</AlertDialogTitle>
                        <AlertDialogDescription className="text-base">
                          Are you sure you want to delete <strong>{selectedTrips.size} trips</strong>? This action cannot be undone. All itineraries, expenses, and members associated with these trips will be permanently removed.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="font-medium">Cancel</AlertDialogCancel>
                        <AlertDialogAction 
                          onClick={handleBulkDelete}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90 font-medium"
                        >
                          Delete {selectedTrips.size} Trips
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}
              </div>

              {/* Results count */}
              <p className="text-sm text-muted-foreground">
                Showing {filteredTrips.length} of {trips.length} trips
                {hasActiveFilters && " (filtered)"}
              </p>
            </div>

            {/* Trip Grid */}
            {filteredTrips.length === 0 ? (
              <Card className="border-2 border-dashed">
                <CardContent className="flex flex-col items-center justify-center py-16">
                  <Search className="h-12 w-12 text-muted-foreground/50 mb-4" />
                  <h3 className="text-xl font-display font-bold mb-2">No trips found</h3>
                  <p className="text-muted-foreground mb-4">Try adjusting your search or filters</p>
                  <Button variant="outline" onClick={clearFilters}>
                    Clear Filters
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredTrips.map((trip) => (
                  <Card 
                    key={trip.id} 
                    className={`border-2 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 group relative overflow-hidden ${
                      selectedTrips.has(trip.id) ? "border-primary bg-primary/5" : ""
                    }`}
                  >
                    {/* Selection Checkbox */}
                    <div className="absolute top-4 left-4 z-10">
                      <Checkbox
                        checked={selectedTrips.has(trip.id)}
                        onCheckedChange={() => toggleTripSelection(trip.id)}
                        className="h-5 w-5 bg-background/80 backdrop-blur-sm"
                      />
                    </div>

                    {/* Delete Button */}
                    <div className="absolute top-4 right-4 z-10">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            className="h-9 w-9 bg-background/80 backdrop-blur-sm hover:bg-destructive hover:text-destructive-foreground transition-colors"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {deletingId === trip.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Trash2 className="h-4 w-4" />
                            )}
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent onClick={(e) => e.stopPropagation()}>
                          <AlertDialogHeader>
                            <AlertDialogTitle className="text-2xl font-display">Delete Trip?</AlertDialogTitle>
                            <AlertDialogDescription className="text-base">
                              Are you sure you want to delete <strong>"{trip.name}"</strong>? This action cannot be undone. All itineraries, expenses, and members associated with this trip will be permanently removed.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="font-medium">Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteTrip(trip.id, trip.name);
                              }}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90 font-medium"
                            >
                              Delete Trip
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>

                    <Link to={`/trips/${trip.id}`}>
                      <CardHeader className="pb-3 pl-12">
                        <div className="flex items-start justify-between pr-10">
                          <CardTitle className="text-2xl font-display line-clamp-1 group-hover:text-primary transition-colors">
                            {trip.name}
                          </CardTitle>
                        </div>
                        <Badge 
                          variant="outline" 
                          className={`w-fit text-sm font-medium capitalize ${statusColors[trip.status] || ''}`}
                        >
                          {trip.status}
                        </Badge>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {trip.description && (
                          <p className="text-base text-muted-foreground line-clamp-2 leading-relaxed">
                            {trip.description}
                          </p>
                        )}
                        
                        <div className="space-y-3 pt-2">
                          {trip.start_date && (
                            <div className="flex items-center gap-3 text-muted-foreground">
                              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
                                <Calendar className="h-4 w-4 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm font-medium text-foreground">
                                  {format(new Date(trip.start_date), "MMM d")}
                                  {trip.end_date && ` - ${format(new Date(trip.end_date), "MMM d, yyyy")}`}
                                </p>
                                {trip.end_date && (
                                  <p className="text-xs text-muted-foreground">
                                    {getDuration(trip.start_date, trip.end_date)} days
                                  </p>
                                )}
                              </div>
                            </div>
                          )}

                          {trip.budget && (
                            <div className="flex items-center gap-3 text-muted-foreground">
                              <div className="w-9 h-9 rounded-lg bg-adventure/10 flex items-center justify-center">
                                <Wallet className="h-4 w-4 text-adventure" />
                              </div>
                              <p className="text-sm font-medium text-foreground">
                                ₹{trip.budget.toLocaleString('en-IN')}
                              </p>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-sm text-primary font-medium pt-4 border-t group-hover:gap-3 transition-all">
                          <span>View Details</span>
                          <ArrowLeft className="h-4 w-4 rotate-180" />
                        </div>
                      </CardContent>
                    </Link>
                  </Card>
                ))}
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};

export default TripList;
