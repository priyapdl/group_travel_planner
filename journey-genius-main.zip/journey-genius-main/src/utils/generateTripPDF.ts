import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { format } from "date-fns";

interface Trip {
  id: string;
  name: string;
  description: string;
  start_date: string;
  end_date: string;
  budget: number;
  status: string;
  estimated_duration: number;
}

interface ItineraryItem {
  id: string;
  day_number: number;
  date: string | null;
  title: string;
  description: string | null;
  start_time: string | null;
  end_time: string | null;
  location: string | null;
  notes: string | null;
}

interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string | null;
  date: string;
}

interface TripMember {
  id: string;
  role: string | null;
  user_id: string;
}

export const generateTripPDF = (
  trip: Trip,
  itinerary: ItineraryItem[],
  expenses: Expense[],
  members: TripMember[]
) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  let yPos = 20;

  // Helper function to add new page if needed
  const checkPageBreak = (requiredSpace: number) => {
    if (yPos + requiredSpace > 270) {
      doc.addPage();
      yPos = 20;
    }
  };

  // Title
  doc.setFontSize(24);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(41, 128, 185);
  doc.text(trip.name, pageWidth / 2, yPos, { align: "center" });
  yPos += 10;

  // Subtitle
  doc.setFontSize(12);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(100, 100, 100);
  doc.text("Trip Itinerary & Details", pageWidth / 2, yPos, { align: "center" });
  yPos += 15;

  // Trip Overview Section
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(44, 62, 80);
  doc.text("Trip Overview", 14, yPos);
  yPos += 8;

  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(60, 60, 60);

  if (trip.description) {
    const descLines = doc.splitTextToSize(trip.description, pageWidth - 28);
    doc.text(descLines, 14, yPos);
    yPos += descLines.length * 5 + 5;
  }

  // Trip Details Table
  const tripDetails = [
    ["Status", trip.status?.charAt(0).toUpperCase() + trip.status?.slice(1) || "N/A"],
    ["Duration", trip.estimated_duration ? `${trip.estimated_duration} days` : "N/A"],
    ["Budget", trip.budget ? `₹${trip.budget.toLocaleString("en-IN")}` : "N/A"],
    ["Start Date", trip.start_date ? format(new Date(trip.start_date), "MMM d, yyyy") : "N/A"],
    ["End Date", trip.end_date ? format(new Date(trip.end_date), "MMM d, yyyy") : "N/A"],
    ["Total Members", members.length.toString()],
  ];

  autoTable(doc, {
    startY: yPos,
    head: [],
    body: tripDetails,
    theme: "plain",
    styles: { fontSize: 10, cellPadding: 3 },
    columnStyles: {
      0: { fontStyle: "bold", cellWidth: 40 },
      1: { cellWidth: "auto" },
    },
    margin: { left: 14 },
  });

  yPos = (doc as any).lastAutoTable.finalY + 15;

  // Itinerary Section
  if (itinerary.length > 0) {
    checkPageBreak(40);
    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(44, 62, 80);
    doc.text("Day-by-Day Itinerary", 14, yPos);
    yPos += 10;

    // Group itinerary by day
    const groupedByDay = itinerary.reduce((acc, item) => {
      if (!acc[item.day_number]) {
        acc[item.day_number] = [];
      }
      acc[item.day_number].push(item);
      return acc;
    }, {} as Record<number, ItineraryItem[]>);

    Object.entries(groupedByDay).forEach(([day, dayItems]) => {
      checkPageBreak(30);
      
      // Day header
      doc.setFillColor(41, 128, 185);
      doc.roundedRect(14, yPos - 5, 25, 8, 2, 2, "F");
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(255, 255, 255);
      doc.text(`Day ${day}`, 16, yPos);
      yPos += 8;

      const itineraryData = dayItems.map((item) => [
        item.start_time ? `${item.start_time}${item.end_time ? ` - ${item.end_time}` : ""}` : "-",
        item.title,
        item.location || "-",
        item.description || "-",
      ]);

      autoTable(doc, {
        startY: yPos,
        head: [["Time", "Activity", "Location", "Description"]],
        body: itineraryData,
        theme: "striped",
        headStyles: { fillColor: [52, 73, 94], fontSize: 9 },
        styles: { fontSize: 9, cellPadding: 3 },
        columnStyles: {
          0: { cellWidth: 30 },
          1: { cellWidth: 45 },
          2: { cellWidth: 40 },
          3: { cellWidth: "auto" },
        },
        margin: { left: 14 },
      });

      yPos = (doc as any).lastAutoTable.finalY + 10;
    });
  }

  // Expenses Section
  if (expenses.length > 0) {
    checkPageBreak(40);
    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(44, 62, 80);
    doc.text("Expense Summary", 14, yPos);
    yPos += 10;

    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);

    const expenseData = expenses.map((expense) => [
      expense.description,
      expense.category || "Other",
      format(new Date(expense.date), "MMM d, yyyy"),
      `₹${expense.amount.toLocaleString("en-IN")}`,
    ]);

    autoTable(doc, {
      startY: yPos,
      head: [["Description", "Category", "Date", "Amount"]],
      body: expenseData,
      foot: [["", "", "Total", `₹${totalExpenses.toLocaleString("en-IN")}`]],
      theme: "striped",
      headStyles: { fillColor: [46, 204, 113], fontSize: 9 },
      footStyles: { fillColor: [39, 174, 96], fontStyle: "bold", fontSize: 10 },
      styles: { fontSize: 9, cellPadding: 3 },
      columnStyles: {
        0: { cellWidth: "auto" },
        1: { cellWidth: 35 },
        2: { cellWidth: 35 },
        3: { cellWidth: 35, halign: "right" },
      },
      margin: { left: 14 },
    });

    yPos = (doc as any).lastAutoTable.finalY + 15;

    // Budget comparison
    if (trip.budget) {
      checkPageBreak(20);
      const remaining = trip.budget - totalExpenses;
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(60, 60, 60);
      doc.text(`Budget: ₹${trip.budget.toLocaleString("en-IN")}`, 14, yPos);
      yPos += 5;
      doc.text(`Spent: ₹${totalExpenses.toLocaleString("en-IN")}`, 14, yPos);
      yPos += 5;
      doc.setTextColor(remaining >= 0 ? 46 : 231, remaining >= 0 ? 204 : 76, remaining >= 0 ? 113 : 60);
      doc.setFont("helvetica", "bold");
      doc.text(`Remaining: ₹${remaining.toLocaleString("en-IN")}`, 14, yPos);
    }
  }

  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(150, 150, 150);
    doc.text(
      `Generated on ${format(new Date(), "MMM d, yyyy")} | Page ${i} of ${pageCount}`,
      pageWidth / 2,
      290,
      { align: "center" }
    );
  }

  // Save the PDF
  const fileName = `${trip.name.replace(/[^a-z0-9]/gi, "_")}_itinerary.pdf`;
  doc.save(fileName);
};
