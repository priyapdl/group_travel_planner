export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      ai_optimizations: {
        Row: {
          applied: boolean | null
          created_at: string | null
          id: string
          input_data: Json | null
          optimization_type: string
          output_data: Json | null
          trip_id: string
        }
        Insert: {
          applied?: boolean | null
          created_at?: string | null
          id?: string
          input_data?: Json | null
          optimization_type: string
          output_data?: Json | null
          trip_id: string
        }
        Update: {
          applied?: boolean | null
          created_at?: string | null
          id?: string
          input_data?: Json | null
          optimization_type?: string
          output_data?: Json | null
          trip_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_optimizations_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
        ]
      }
      destinations: {
        Row: {
          address: string | null
          average_visit_duration: number | null
          category: string | null
          created_at: string | null
          description: string | null
          entry_fee: number | null
          id: string
          images: Json | null
          latitude: number | null
          longitude: number | null
          name: string
          popular_times: Json | null
          rating: number | null
        }
        Insert: {
          address?: string | null
          average_visit_duration?: number | null
          category?: string | null
          created_at?: string | null
          description?: string | null
          entry_fee?: number | null
          id?: string
          images?: Json | null
          latitude?: number | null
          longitude?: number | null
          name: string
          popular_times?: Json | null
          rating?: number | null
        }
        Update: {
          address?: string | null
          average_visit_duration?: number | null
          category?: string | null
          created_at?: string | null
          description?: string | null
          entry_fee?: number | null
          id?: string
          images?: Json | null
          latitude?: number | null
          longitude?: number | null
          name?: string
          popular_times?: Json | null
          rating?: number | null
        }
        Relationships: []
      }
      expense_splits: {
        Row: {
          amount: number
          created_at: string
          expense_id: string
          id: string
          paid: boolean
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          expense_id: string
          id?: string
          paid?: boolean
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          expense_id?: string
          id?: string
          paid?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "expense_splits_expense_id_fkey"
            columns: ["expense_id"]
            isOneToOne: false
            referencedRelation: "expenses"
            referencedColumns: ["id"]
          },
        ]
      }
      expenses: {
        Row: {
          amount: number
          category: string | null
          created_at: string
          created_by: string
          date: string
          description: string
          id: string
          receipt_url: string | null
          trip_id: string
          updated_at: string
        }
        Insert: {
          amount: number
          category?: string | null
          created_at?: string
          created_by: string
          date?: string
          description: string
          id?: string
          receipt_url?: string | null
          trip_id: string
          updated_at?: string
        }
        Update: {
          amount?: number
          category?: string | null
          created_at?: string
          created_by?: string
          date?: string
          description?: string
          id?: string
          receipt_url?: string | null
          trip_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "expenses_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
        ]
      }
      itinerary: {
        Row: {
          created_at: string
          date: string | null
          day_number: number
          description: string | null
          end_time: string | null
          id: string
          location: string | null
          notes: string | null
          start_time: string | null
          title: string
          trip_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          date?: string | null
          day_number: number
          description?: string | null
          end_time?: string | null
          id?: string
          location?: string | null
          notes?: string | null
          start_time?: string | null
          title: string
          trip_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          date?: string | null
          day_number?: number
          description?: string | null
          end_time?: string | null
          id?: string
          location?: string | null
          notes?: string | null
          start_time?: string | null
          title?: string
          trip_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "itinerary_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
        ]
      }
      nearby_places: {
        Row: {
          address: string | null
          amenities: Json | null
          contact_info: Json | null
          created_at: string | null
          destination_id: string
          distance_from_destination: number | null
          id: string
          latitude: number | null
          longitude: number | null
          name: string
          price_level: number | null
          rating: number | null
          type: string
        }
        Insert: {
          address?: string | null
          amenities?: Json | null
          contact_info?: Json | null
          created_at?: string | null
          destination_id: string
          distance_from_destination?: number | null
          id?: string
          latitude?: number | null
          longitude?: number | null
          name: string
          price_level?: number | null
          rating?: number | null
          type: string
        }
        Update: {
          address?: string | null
          amenities?: Json | null
          contact_info?: Json | null
          created_at?: string | null
          destination_id?: string
          distance_from_destination?: number | null
          id?: string
          latitude?: number | null
          longitude?: number | null
          name?: string
          price_level?: number | null
          rating?: number | null
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "nearby_places_destination_id_fkey"
            columns: ["destination_id"]
            isOneToOne: false
            referencedRelation: "destinations"
            referencedColumns: ["id"]
          },
        ]
      }
      routes: {
        Row: {
          created_at: string | null
          distance: number | null
          duration: number | null
          from_destination_id: string
          id: string
          route_polyline: string | null
          to_destination_id: string
          toll_cost: number | null
          traffic_condition: string | null
          transport_mode: string | null
          trip_id: string
        }
        Insert: {
          created_at?: string | null
          distance?: number | null
          duration?: number | null
          from_destination_id: string
          id?: string
          route_polyline?: string | null
          to_destination_id: string
          toll_cost?: number | null
          traffic_condition?: string | null
          transport_mode?: string | null
          trip_id: string
        }
        Update: {
          created_at?: string | null
          distance?: number | null
          duration?: number | null
          from_destination_id?: string
          id?: string
          route_polyline?: string | null
          to_destination_id?: string
          toll_cost?: number | null
          traffic_condition?: string | null
          transport_mode?: string | null
          trip_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "routes_from_destination_id_fkey"
            columns: ["from_destination_id"]
            isOneToOne: false
            referencedRelation: "destinations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "routes_to_destination_id_fkey"
            columns: ["to_destination_id"]
            isOneToOne: false
            referencedRelation: "destinations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "routes_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
        ]
      }
      trip_destinations: {
        Row: {
          actual_arrival_time: string | null
          actual_departure_time: string | null
          created_at: string | null
          destination_id: string
          id: string
          notes: string | null
          planned_arrival_time: string | null
          planned_departure_time: string | null
          priority: Database["public"]["Enums"]["destination_priority"] | null
          trip_id: string
          visit_order: number | null
          visited: boolean | null
        }
        Insert: {
          actual_arrival_time?: string | null
          actual_departure_time?: string | null
          created_at?: string | null
          destination_id: string
          id?: string
          notes?: string | null
          planned_arrival_time?: string | null
          planned_departure_time?: string | null
          priority?: Database["public"]["Enums"]["destination_priority"] | null
          trip_id: string
          visit_order?: number | null
          visited?: boolean | null
        }
        Update: {
          actual_arrival_time?: string | null
          actual_departure_time?: string | null
          created_at?: string | null
          destination_id?: string
          id?: string
          notes?: string | null
          planned_arrival_time?: string | null
          planned_departure_time?: string | null
          priority?: Database["public"]["Enums"]["destination_priority"] | null
          trip_id?: string
          visit_order?: number | null
          visited?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "trip_destinations_destination_id_fkey"
            columns: ["destination_id"]
            isOneToOne: false
            referencedRelation: "destinations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "trip_destinations_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
        ]
      }
      trip_feedback: {
        Row: {
          comment: string | null
          created_at: string | null
          destination_id: string | null
          helpful_count: number | null
          id: string
          photos: Json | null
          rating: number | null
          trip_id: string
          user_id: string
        }
        Insert: {
          comment?: string | null
          created_at?: string | null
          destination_id?: string | null
          helpful_count?: number | null
          id?: string
          photos?: Json | null
          rating?: number | null
          trip_id: string
          user_id: string
        }
        Update: {
          comment?: string | null
          created_at?: string | null
          destination_id?: string | null
          helpful_count?: number | null
          id?: string
          photos?: Json | null
          rating?: number | null
          trip_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "trip_feedback_destination_id_fkey"
            columns: ["destination_id"]
            isOneToOne: false
            referencedRelation: "destinations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "trip_feedback_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
        ]
      }
      trip_members: {
        Row: {
          id: string
          joined_at: string | null
          role: string | null
          trip_id: string
          user_id: string
        }
        Insert: {
          id?: string
          joined_at?: string | null
          role?: string | null
          trip_id: string
          user_id: string
        }
        Update: {
          id?: string
          joined_at?: string | null
          role?: string | null
          trip_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "trip_members_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
        ]
      }
      trips: {
        Row: {
          budget: number | null
          created_at: string | null
          description: string | null
          end_date: string | null
          estimated_duration: number | null
          id: string
          name: string
          start_date: string | null
          status: Database["public"]["Enums"]["trip_status"] | null
          total_distance: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          budget?: number | null
          created_at?: string | null
          description?: string | null
          end_date?: string | null
          estimated_duration?: number | null
          id?: string
          name: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["trip_status"] | null
          total_distance?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          budget?: number | null
          created_at?: string | null
          description?: string | null
          end_date?: string | null
          estimated_duration?: number | null
          id?: string
          name?: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["trip_status"] | null
          total_distance?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_preferences: {
        Row: {
          accessibility_needs: Json | null
          avoid_tolls: boolean | null
          budget_preference: string | null
          created_at: string | null
          id: string
          interests: Json | null
          max_daily_travel_time: number | null
          preferred_meal_times: Json | null
          preferred_transport_mode: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          accessibility_needs?: Json | null
          avoid_tolls?: boolean | null
          budget_preference?: string | null
          created_at?: string | null
          id?: string
          interests?: Json | null
          max_daily_travel_time?: number | null
          preferred_meal_times?: Json | null
          preferred_transport_mode?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          accessibility_needs?: Json | null
          avoid_tolls?: boolean | null
          budget_preference?: string | null
          created_at?: string | null
          id?: string
          interests?: Json | null
          max_daily_travel_time?: number | null
          preferred_meal_times?: Json | null
          preferred_transport_mode?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      is_trip_member: {
        Args: { _trip_id: string; _user_id: string }
        Returns: boolean
      }
      is_trip_owner: {
        Args: { _trip_id: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      destination_priority: "must_visit" | "recommended" | "optional"
      trip_status:
        | "planning"
        | "confirmed"
        | "ongoing"
        | "completed"
        | "cancelled"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      destination_priority: ["must_visit", "recommended", "optional"],
      trip_status: [
        "planning",
        "confirmed",
        "ongoing",
        "completed",
        "cancelled",
      ],
    },
  },
} as const
