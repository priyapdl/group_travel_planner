import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { tripDetails, existingDestinations } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY not configured');
    }

    const systemPrompt = `You are an AI travel planner specializing in Indian destinations. Analyze the trip details and provide:

1. **Route Comparison**: Generate 3 different route options (Fastest, Most Scenic, Budget-Friendly), each with:
   - Route name and description
   - Estimated travel time (hours)
   - Total distance (kilometers)
   - Estimated cost (INR) including fuel/transport, tolls, and meals
   - Key highlights of the route
   - Best transport mode (car/train/bus)

2. **Top Destinations**: Suggest destinations based on duration, budget, and preferences

3. **Famous Places**: List must-visit places in each destination with estimated visit duration

4. **Optimal Visit Sequence**: Recommend the best order to visit places for efficiency

5. **Nearby Amenities**: Suggest restaurants and accommodations near each destination

Format your response with clear markdown sections using ## headers. Be specific with numbers and practical details for India. Consider travel distances, time constraints, and seasonal factors.`;

    const userPrompt = `Trip Details:
- Duration: ${tripDetails.duration} days
- Budget: $${tripDetails.budget || 'flexible'}
- Start Date: ${tripDetails.startDate || 'flexible'}
- Description: ${tripDetails.description || 'Not specified'}
${existingDestinations?.length ? `\nAlready selected: ${existingDestinations.join(', ')}` : ''}

Provide detailed destination suggestions with places to visit, optimal routes, and travel tips for this trip.`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Payment required. Please add credits to your workspace.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      throw new Error(`AI API error: ${response.status}`);
    }

    const data = await response.json();
    const suggestions = data.choices[0].message.content;

    return new Response(
      JSON.stringify({ suggestions }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in trip-suggestions:', error);
    const errorMessage = error instanceof Error ? error.message : 'Failed to generate suggestions';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});