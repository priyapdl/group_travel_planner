-- Create enum for trip status
CREATE TYPE trip_status AS ENUM ('planning', 'confirmed', 'ongoing', 'completed', 'cancelled');

-- Create enum for destination priority
CREATE TYPE destination_priority AS ENUM ('must_visit', 'recommended', 'optional');

-- Trips table - Main container for group trips
CREATE TABLE public.trips (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  start_date DATE,
  end_date DATE,
  status trip_status DEFAULT 'planning',
  total_distance NUMERIC(10, 2), -- in kilometers
  estimated_duration INTEGER, -- in minutes
  budget NUMERIC(10, 2),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Trip members table - For group collaboration
CREATE TABLE public.trip_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id UUID NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT DEFAULT 'member', -- 'owner', 'editor', 'viewer', 'member'
  joined_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(trip_id, user_id)
);

-- Destinations table - Reusable places
CREATE TABLE public.destinations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  address TEXT,
  latitude NUMERIC(10, 7),
  longitude NUMERIC(10, 7),
  category TEXT, -- 'temple', 'beach', 'mountain', 'restaurant', 'hotel', etc.
  rating NUMERIC(3, 2), -- 0-5 rating
  popular_times JSONB, -- Store popular visiting times
  average_visit_duration INTEGER, -- in minutes
  entry_fee NUMERIC(10, 2),
  images JSONB, -- Array of image URLs
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Trip destinations - Destinations added to specific trips
CREATE TABLE public.trip_destinations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id UUID NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
  destination_id UUID NOT NULL REFERENCES public.destinations(id) ON DELETE CASCADE,
  visit_order INTEGER, -- Order in the optimized route
  priority destination_priority DEFAULT 'recommended',
  planned_arrival_time TIMESTAMPTZ,
  planned_departure_time TIMESTAMPTZ,
  actual_arrival_time TIMESTAMPTZ,
  actual_departure_time TIMESTAMPTZ,
  notes TEXT,
  visited BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(trip_id, destination_id)
);

-- Routes table - Optimized paths between destinations
CREATE TABLE public.routes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id UUID NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
  from_destination_id UUID NOT NULL REFERENCES public.destinations(id),
  to_destination_id UUID NOT NULL REFERENCES public.destinations(id),
  distance NUMERIC(10, 2), -- in kilometers
  duration INTEGER, -- in minutes
  route_polyline TEXT, -- Encoded polyline for map visualization
  transport_mode TEXT DEFAULT 'driving', -- 'driving', 'walking', 'transit'
  traffic_condition TEXT, -- 'light', 'moderate', 'heavy'
  toll_cost NUMERIC(10, 2),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- User preferences table - For AI personalization
CREATE TABLE public.user_preferences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  preferred_transport_mode TEXT DEFAULT 'driving',
  max_daily_travel_time INTEGER DEFAULT 480, -- in minutes (8 hours)
  interests JSONB, -- Array of interests: ['temples', 'beaches', 'hiking']
  budget_preference TEXT DEFAULT 'moderate', -- 'budget', 'moderate', 'luxury'
  accessibility_needs JSONB, -- Special requirements
  avoid_tolls BOOLEAN DEFAULT false,
  preferred_meal_times JSONB, -- {breakfast: "08:00", lunch: "13:00", dinner: "19:00"}
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Nearby places table - Restaurants, hotels near destinations
CREATE TABLE public.nearby_places (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  destination_id UUID NOT NULL REFERENCES public.destinations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT NOT NULL, -- 'restaurant', 'hotel', 'cafe', 'parking'
  address TEXT,
  latitude NUMERIC(10, 7),
  longitude NUMERIC(10, 7),
  distance_from_destination NUMERIC(10, 2), -- in kilometers
  rating NUMERIC(3, 2),
  price_level INTEGER, -- 1-4 scale
  contact_info JSONB, -- {phone, website, email}
  amenities JSONB, -- Array of amenities
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Trip feedback table - User reviews and feedback
CREATE TABLE public.trip_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id UUID NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  destination_id UUID REFERENCES public.destinations(id) ON DELETE SET NULL,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  photos JSONB, -- Array of photo URLs
  helpful_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- AI optimization history - Track AI suggestions and optimizations
CREATE TABLE public.ai_optimizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id UUID NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
  optimization_type TEXT NOT NULL, -- 'route', 'destination_suggestion', 'time_optimization'
  input_data JSONB, -- What was sent to AI
  output_data JSONB, -- What AI suggested
  applied BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security on all tables
ALTER TABLE public.trips ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trip_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trip_destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nearby_places ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trip_feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_optimizations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for trips
CREATE POLICY "Users can view their own trips and trips they're members of"
  ON public.trips FOR SELECT
  USING (
    auth.uid() = user_id OR 
    EXISTS (
      SELECT 1 FROM public.trip_members 
      WHERE trip_members.trip_id = trips.id 
      AND trip_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create their own trips"
  ON public.trips FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Trip owners can update their trips"
  ON public.trips FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Trip owners can delete their trips"
  ON public.trips FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for trip_members
CREATE POLICY "Users can view members of their trips"
  ON public.trip_members FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.trips 
      WHERE trips.id = trip_members.trip_id 
      AND (trips.user_id = auth.uid() OR trip_members.user_id = auth.uid())
    )
  );

CREATE POLICY "Trip owners can add members"
  ON public.trip_members FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.trips 
      WHERE trips.id = trip_id 
      AND trips.user_id = auth.uid()
    )
  );

CREATE POLICY "Trip owners can remove members"
  ON public.trip_members FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.trips 
      WHERE trips.id = trip_id 
      AND trips.user_id = auth.uid()
    )
  );

-- RLS Policies for destinations (public read, authenticated write)
CREATE POLICY "Anyone can view destinations"
  ON public.destinations FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create destinations"
  ON public.destinations FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- RLS Policies for trip_destinations
CREATE POLICY "Users can view destinations in their trips"
  ON public.trip_destinations FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.trips 
      WHERE trips.id = trip_id 
      AND (
        trips.user_id = auth.uid() OR 
        EXISTS (
          SELECT 1 FROM public.trip_members 
          WHERE trip_members.trip_id = trips.id 
          AND trip_members.user_id = auth.uid()
        )
      )
    )
  );

CREATE POLICY "Users can add destinations to their trips"
  ON public.trip_destinations FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.trips 
      WHERE trips.id = trip_id 
      AND (
        trips.user_id = auth.uid() OR 
        EXISTS (
          SELECT 1 FROM public.trip_members 
          WHERE trip_members.trip_id = trips.id 
          AND trip_members.user_id = auth.uid()
          AND trip_members.role IN ('owner', 'editor')
        )
      )
    )
  );

CREATE POLICY "Users can update destinations in their trips"
  ON public.trip_destinations FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.trips 
      WHERE trips.id = trip_id 
      AND (
        trips.user_id = auth.uid() OR 
        EXISTS (
          SELECT 1 FROM public.trip_members 
          WHERE trip_members.trip_id = trips.id 
          AND trip_members.user_id = auth.uid()
          AND trip_members.role IN ('owner', 'editor')
        )
      )
    )
  );

CREATE POLICY "Users can delete destinations from their trips"
  ON public.trip_destinations FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.trips 
      WHERE trips.id = trip_id 
      AND (
        trips.user_id = auth.uid() OR 
        EXISTS (
          SELECT 1 FROM public.trip_members 
          WHERE trip_members.trip_id = trips.id 
          AND trip_members.user_id = auth.uid()
          AND trip_members.role IN ('owner', 'editor')
        )
      )
    )
  );

-- RLS Policies for routes
CREATE POLICY "Users can view routes in their trips"
  ON public.routes FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.trips 
      WHERE trips.id = trip_id 
      AND (
        trips.user_id = auth.uid() OR 
        EXISTS (
          SELECT 1 FROM public.trip_members 
          WHERE trip_members.trip_id = trips.id 
          AND trip_members.user_id = auth.uid()
        )
      )
    )
  );

CREATE POLICY "Users can create routes for their trips"
  ON public.routes FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.trips 
      WHERE trips.id = trip_id 
      AND trips.user_id = auth.uid()
    )
  );

-- RLS Policies for user_preferences
CREATE POLICY "Users can view their own preferences"
  ON public.user_preferences FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own preferences"
  ON public.user_preferences FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own preferences"
  ON public.user_preferences FOR UPDATE
  USING (auth.uid() = user_id);

-- RLS Policies for nearby_places
CREATE POLICY "Anyone can view nearby places"
  ON public.nearby_places FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can add nearby places"
  ON public.nearby_places FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- RLS Policies for trip_feedback
CREATE POLICY "Users can view all feedback"
  ON public.trip_feedback FOR SELECT
  USING (true);

CREATE POLICY "Users can create their own feedback"
  ON public.trip_feedback FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own feedback"
  ON public.trip_feedback FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own feedback"
  ON public.trip_feedback FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for ai_optimizations
CREATE POLICY "Users can view AI optimizations for their trips"
  ON public.ai_optimizations FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.trips 
      WHERE trips.id = trip_id 
      AND (
        trips.user_id = auth.uid() OR 
        EXISTS (
          SELECT 1 FROM public.trip_members 
          WHERE trip_members.trip_id = trips.id 
          AND trip_members.user_id = auth.uid()
        )
      )
    )
  );

CREATE POLICY "System can create AI optimizations"
  ON public.ai_optimizations FOR INSERT
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX idx_trips_user_id ON public.trips(user_id);
CREATE INDEX idx_trips_status ON public.trips(status);
CREATE INDEX idx_trip_members_trip_id ON public.trip_members(trip_id);
CREATE INDEX idx_trip_members_user_id ON public.trip_members(user_id);
CREATE INDEX idx_destinations_category ON public.destinations(category);
CREATE INDEX idx_trip_destinations_trip_id ON public.trip_destinations(trip_id);
CREATE INDEX idx_trip_destinations_visit_order ON public.trip_destinations(trip_id, visit_order);
CREATE INDEX idx_routes_trip_id ON public.routes(trip_id);
CREATE INDEX idx_nearby_places_destination_id ON public.nearby_places(destination_id);
CREATE INDEX idx_nearby_places_type ON public.nearby_places(type);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
CREATE TRIGGER update_trips_updated_at
  BEFORE UPDATE ON public.trips
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_preferences_updated_at
  BEFORE UPDATE ON public.user_preferences
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();