-- Drop existing problematic policies
DROP POLICY IF EXISTS "Users can view their own trips and trips they're members of" ON public.trips;
DROP POLICY IF EXISTS "Users can view members of their trips" ON public.trip_members;

-- Create security definer functions to avoid infinite recursion
CREATE OR REPLACE FUNCTION public.is_trip_member(_trip_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM trip_members
    WHERE trip_id = _trip_id
      AND user_id = _user_id
  );
$$;

CREATE OR REPLACE FUNCTION public.is_trip_owner(_trip_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM trips
    WHERE id = _trip_id
      AND user_id = _user_id
  );
$$;

-- Recreate policies using security definer functions
CREATE POLICY "Users can view their own trips and trips they're members of"
ON public.trips
FOR SELECT
TO authenticated
USING (
  auth.uid() = user_id 
  OR public.is_trip_member(id, auth.uid())
);

CREATE POLICY "Users can view members of their trips"
ON public.trip_members
FOR SELECT
TO authenticated
USING (
  public.is_trip_owner(trip_id, auth.uid())
  OR user_id = auth.uid()
);