-- Create expenses table
CREATE TABLE public.expenses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  trip_id UUID NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  description TEXT NOT NULL,
  amount NUMERIC(10,2) NOT NULL,
  category TEXT,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  receipt_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create expense_splits table
CREATE TABLE public.expense_splits (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  expense_id UUID NOT NULL REFERENCES public.expenses(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id),
  amount NUMERIC(10,2) NOT NULL,
  paid BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(expense_id, user_id)
);

-- Enable RLS
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expense_splits ENABLE ROW LEVEL SECURITY;

-- RLS Policies for expenses
CREATE POLICY "Users can view expenses in their trips"
ON public.expenses
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.trips
    WHERE trips.id = expenses.trip_id
    AND (
      trips.user_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM public.trip_members
        WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
      )
    )
  )
);

CREATE POLICY "Users can create expenses in their trips"
ON public.expenses
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.trips
    WHERE trips.id = expenses.trip_id
    AND (
      trips.user_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM public.trip_members
        WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
        AND trip_members.role IN ('owner', 'editor')
      )
    )
  )
);

CREATE POLICY "Users can update their own expenses"
ON public.expenses
FOR UPDATE
USING (created_by = auth.uid());

CREATE POLICY "Users can delete their own expenses"
ON public.expenses
FOR DELETE
USING (created_by = auth.uid());

-- RLS Policies for expense_splits
CREATE POLICY "Users can view expense splits in their trips"
ON public.expense_splits
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.expenses
    JOIN public.trips ON trips.id = expenses.trip_id
    WHERE expenses.id = expense_splits.expense_id
    AND (
      trips.user_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM public.trip_members
        WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
      )
    )
  )
);

CREATE POLICY "Users can create expense splits"
ON public.expense_splits
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.expenses
    JOIN public.trips ON trips.id = expenses.trip_id
    WHERE expenses.id = expense_splits.expense_id
    AND (
      trips.user_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM public.trip_members
        WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
        AND trip_members.role IN ('owner', 'editor')
      )
    )
  )
);

CREATE POLICY "Users can update their own expense splits"
ON public.expense_splits
FOR UPDATE
USING (user_id = auth.uid());

-- Add triggers for updated_at
CREATE TRIGGER update_expenses_updated_at
BEFORE UPDATE ON public.expenses
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create itinerary table for day-by-day planning
CREATE TABLE public.itinerary (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  trip_id UUID NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
  day_number INTEGER NOT NULL,
  date DATE,
  title TEXT NOT NULL,
  description TEXT,
  start_time TIME,
  end_time TIME,
  location TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(trip_id, day_number)
);

-- Enable RLS for itinerary
ALTER TABLE public.itinerary ENABLE ROW LEVEL SECURITY;

-- RLS Policies for itinerary
CREATE POLICY "Users can view itinerary in their trips"
ON public.itinerary
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.trips
    WHERE trips.id = itinerary.trip_id
    AND (
      trips.user_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM public.trip_members
        WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
      )
    )
  )
);

CREATE POLICY "Users can create itinerary items in their trips"
ON public.itinerary
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.trips
    WHERE trips.id = itinerary.trip_id
    AND (
      trips.user_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM public.trip_members
        WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
        AND trip_members.role IN ('owner', 'editor')
      )
    )
  )
);

CREATE POLICY "Users can update itinerary in their trips"
ON public.itinerary
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.trips
    WHERE trips.id = itinerary.trip_id
    AND (
      trips.user_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM public.trip_members
        WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
        AND trip_members.role IN ('owner', 'editor')
      )
    )
  )
);

CREATE POLICY "Users can delete itinerary in their trips"
ON public.itinerary
FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM public.trips
    WHERE trips.id = itinerary.trip_id
    AND (
      trips.user_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM public.trip_members
        WHERE trip_members.trip_id = trips.id
        AND trip_members.user_id = auth.uid()
        AND trip_members.role IN ('owner', 'editor')
      )
    )
  )
);

-- Add trigger for itinerary updated_at
CREATE TRIGGER update_itinerary_updated_at
BEFORE UPDATE ON public.itinerary
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();